## 2026-09-09T16:48:12Z

Objective:
Implement Milestone 1: Backend Outreach & Webhook Engine.
1. Read:
   - /home/ewilliamhe/hatake-shop/.agents/ORIGINAL_REQUEST.md
   - /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/PROJECT.md
   - /home/ewilliamhe/hatake-shop/.agents/explorer_survey_1/handoff.md
   - /home/ewilliamhe/hatake-shop/.agents/explorer_survey_3/handoff.md

2. Scope of Implementation:
   A. Database Schema & Migration:
      - Update `src/db/schema.ts` to include `'opened'` and `'clicked'` in the `leads.status` enum.
      - Add `clickedAt: timestamp('clicked_at')` and `resendEmailId: text('resend_email_id')` to `leads` in `src/db/schema.ts`.
      - Run SQL migration against the database (e.g. execute `ALTER TABLE leads ADD COLUMN IF NOT EXISTS clicked_at timestamp; ALTER TABLE leads ADD COLUMN IF NOT EXISTS resend_email_id text;` using a tsx script with `db.execute(...)`).
   B. Resend Configuration:
      - Update `.env` to include:
        `RESEND_API_KEY=re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv`
        `RESEND_FROM_EMAIL=b2b@hatake.social`
        `RESEND_REPLY_TO=ernst@hatake.eu`
      - Ensure `server.ts` instantiates Resend using `process.env.RESEND_API_KEY || "re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv"`.
   C. Batch Dispatch Endpoint (`POST /api-v2/admin/leads/send`):
      - Query pending unrecruited leads up to limit (default 50).
      - Dispatch emails using Resend SDK (`resend.batch.send` or robust loop) with:
        - `from: process.env.RESEND_FROM_EMAIL || "Hatake B2B <b2b@hatake.social>"`
        - `replyTo: process.env.RESEND_REPLY_TO || "ernst@hatake.eu"`
        - Tag each email with `{ name: 'lead_id', value: String(lead.id) }`.
        - Record `resend_email_id`, `sent_at`, `status: 'sent'`, and `invite_token_hash`.
      - Ensure it handles responses gracefully without 500 errors.
   D. Dedicated Resend Webhook Endpoint in `server.ts`:
      - Expose `POST /api-v2/webhooks/resend`.
      - Securely parse JSON event payload (supporting both live Resend payloads and simulated curl payloads).
      - Support `email.delivered`, `email.opened`, `email.clicked`.
      - Implement 3-tier lead matching (`tags.lead_id` -> `resend_email_id` -> `email`).
      - Enforce forward-only status monotonicity:
        - `email.opened`: update status to `'opened'` and set `openedAt` only if current status is `'pending'` or `'sent'` (never overwrite `'clicked'` or `'recruited'`).
        - `email.clicked`: update status to `'clicked'` and set `clickedAt` only if current status is `'pending'`, `'sent'`, or `'opened'` (never overwrite `'recruited'`).
      - Emit real-time Socket.IO event: `(req as any).io?.emit("lead_updated", { id: lead.id, status: newStatus, openedAt, clickedAt })`.
      - Return HTTP 200 `{ received: true, leadId: lead.id, status: newStatus }`.
   E. Metrics Query Fix:
      - Update `server.ts:487` and `server.ts:649` so `sentCount` counts all contacted leads (`not(eq(leads.status, 'pending'))`).

3. Verification:
   - Run type check: `npm run lint` or `npx tsc --noEmit`.
   - Run test scripts verifying:
     - `POST /api-v2/webhooks/resend` parses simulated Resend JSON and updates a test lead to `'opened'` and `'clicked'` in Postgres.
     - `POST /api-v2/admin/leads/send` executes successfully without 500 error.
   - Document commands executed and exact outputs in your handoff report.

File Ownership:
- You exclusively own `src/db/schema.ts`, `.env`, and `server.ts`.
- DO NOT modify frontend UI files (`src/pages/AdminDashboard.tsx`) or `tests/e2e/`.

## 2026-09-09T16:55:21Z

Server restart recovery notice from orchestrator:
E2E Test Writer has completed all test suites (Tiers 1-4) in `tests/e2e/` and published `TEST_READY.md`.
Resume implementation and verification, test endpoints and execute tests, and deliver handoff report to `.agents/worker_m1_1/handoff.md`.
