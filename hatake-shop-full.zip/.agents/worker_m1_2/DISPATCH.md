## 2026-09-09T17:00:34Z
You are worker_m1_2, working in /home/ewilliamhe/hatake-shop/.agents/worker_m1_2.
Your role is: Milestone 1 Backend Worker (Replacement for worker_m1_1).

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Objective:
Implement Milestone 1: Backend Outreach & Webhook Engine.

Context files to read:
- /home/ewilliamhe/hatake-shop/.agents/ORIGINAL_REQUEST.md
- /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/PROJECT.md
- /home/ewilliamhe/hatake-shop/.agents/explorer_survey_1/handoff.md
- /home/ewilliamhe/hatake-shop/.agents/explorer_survey_3/handoff.md
- /home/ewilliamhe/hatake-shop/TEST_READY.md and /home/ewilliamhe/hatake-shop/tests/e2e/**

Implementation Tasks:
1. Database Schema & Migration:
   - Update `src/db/schema.ts` to add `'opened'` and `'clicked'` to the `leads.status` enum:
     `status: text('status', { enum: ['pending', 'sent', 'opened', 'clicked', 'recruited', 'failed'] }).default('pending')`
   - Add `clickedAt: timestamp('clicked_at')` and `resendEmailId: text('resend_email_id')` to `leads` table in `src/db/schema.ts`.
   - Apply the migration to Neon Postgres using a tsx script:
     `ALTER TABLE leads ADD COLUMN IF NOT EXISTS clicked_at timestamp;`
     `ALTER TABLE leads ADD COLUMN IF NOT EXISTS resend_email_id text;`
2. Resend Credentials & Config:
   - Update `.env`:
     `RESEND_API_KEY=re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv`
     `RESEND_FROM_EMAIL=b2b@hatake.social`
     `RESEND_REPLY_TO=ernst@hatake.eu`
   - In `server.ts`, initialize Resend:
     `const resend = new Resend(process.env.RESEND_API_KEY || "re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv");`
3. Batch Outreach Dispatch Endpoint (`POST /api-v2/admin/leads/send`):
   - Query pending leads: `where(eq(leads.status, 'pending')).limit(limit || 50)`.
   - Send emails using Resend SDK with:
     - `from: process.env.RESEND_FROM_EMAIL || "Hatake B2B <b2b@hatake.social>"`
     - `replyTo: process.env.RESEND_REPLY_TO || "ernst@hatake.eu"`
     - Tag each email with `{ name: 'lead_id', value: String(lead.id) }`.
     - Save `resend_email_id`, `sent_at`, `status: 'sent'`, and `invite_token_hash`.
   - Ensure it returns `{ success: true, sent: count, message: ... }` without 500 errors.
4. Resend Webhook Endpoint (`POST /api-v2/webhooks/resend`):
   - Expose `POST /api-v2/webhooks/resend` in `server.ts`.
   - Parse JSON payload (both live Resend payloads and simulated curl payloads).
   - Support `email.delivered`, `email.opened`, `email.clicked`.
   - 3-tier lead matching: `data.tags?.lead_id` -> `data.email_id` (matching `resend_email_id`) -> `data.to[0]` (matching `email`).
   - Forward-only status updates (monotonicity):
     - `email.opened`: update `status = 'opened'`, `openedAt = now` ONLY if current status is `'pending'` or `'sent'` (never overwrite `'clicked'` or `'recruited'`).
     - `email.clicked`: update `status = 'clicked'`, `clickedAt = now` ONLY if current status is `'pending'`, `'sent'`, or `'opened'` (never overwrite `'recruited'`).
   - Emit real-time Socket.IO event: `(req as any).io?.emit("lead_updated", { id: lead.id, status: newStatus, openedAt, clickedAt })`.
   - Return HTTP 200 `{ received: true, leadId: lead.id, status: newStatus }`.
5. Metrics Query Fix:
   - Update `server.ts:487` and `server.ts:649` so `sentCount` counts all contacted leads (`not(eq(leads.status, 'pending'))`).
6. Verification:
   - Run type check: `npm run lint` or `npx tsc --noEmit`.
   - Test endpoints and run E2E test suite: `npx tsx tests/e2e/run_all.ts`.
   - Verify that simulated Resend JSON payloads update mock leads to 'opened' and 'clicked' in Postgres.

File Ownership:
- You exclusively own `src/db/schema.ts`, `.env`, and `server.ts`.
- DO NOT modify frontend UI files (`src/pages/AdminDashboard.tsx`) or `tests/e2e/`.

Write your handoff report to `/home/ewilliamhe/hatake-shop/.agents/worker_m1_2/handoff.md` and send a message back when complete.
