# BRIEFING — 2026-09-09T17:00:34Z

## Mission
Implement Milestone 1: Backend Outreach & Webhook Engine (schema, credentials, outreach dispatch, webhook, metrics).

## 🔒 My Identity
- Archetype: worker_m1_2
- Roles: implementer, qa, specialist
- Working directory: /home/ewilliamhe/hatake-shop/.agents/worker_m1_2
- Original parent: f5e46554-a9ce-4f3b-87b0-a2fe5c0d3486
- Milestone: Milestone 1 - Backend Outreach & Webhook Engine

## 🔒 Key Constraints
- DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, dummy implementations.
- Exclusively own `src/db/schema.ts`, `.env`, and `server.ts`.
- DO NOT modify frontend UI files (`src/pages/AdminDashboard.tsx`) or `tests/e2e/`.
- Forward-only status updates (monotonicity): opened only if pending/sent; clicked only if pending/sent/opened; never overwrite recruited.
- 3-tier lead matching for webhook.
- Socket.IO emission on lead update.
- Metrics queries count all contacted leads (`not(eq(leads.status, 'pending'))`).

## Current Parent
- Conversation ID: f5e46554-a9ce-4f3b-87b0-a2fe5c0d3486
- Updated: not yet

## Task Summary
- **What to build**:
  1. Database Schema & Migration: status enum add 'opened', 'clicked'; clickedAt, resendEmailId columns; apply migration to Neon Postgres.
  2. Resend Credentials & Config: .env and server.ts resend instance.
  3. Batch Outreach Dispatch Endpoint (`POST /api-v2/admin/leads/send`): tag lead_id, save resend_email_id, sent_at, status='sent', invite_token_hash.
  4. Resend Webhook Endpoint (`POST /api-v2/webhooks/resend`): parse JSON, support email.delivered, email.opened, email.clicked, 3-tier lead matching, forward-only status updates, socket.io emit.
  5. Metrics Query Fix in server.ts:487 and server.ts:649.
  6. Verification: tsc/lint, run E2E test suite `npx tsx tests/e2e/run_all.ts`, verify mock leads.
- **Success criteria**: All M1 E2E tests pass, webhook genuinely handles payloads and updates DB, socket.io emits events.
- **Interface contracts**: /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/PROJECT.md
- **Code layout**: src/db/schema.ts, server.ts, .env

## Change Tracker
- **Files modified**: None yet
- **Build status**: Not run yet
- **Pending issues**: None

## Quality Status
- **Build/test result**: Not run yet
- **Lint status**: Not run yet
- **Tests added/modified**: E2E suite already exists in tests/e2e/

## Key Decisions Made
- Initializing workspace and reading context files.

## Artifact Index
- /home/ewilliamhe/hatake-shop/.agents/worker_m1_2/DISPATCH.md — Assignment instructions
- /home/ewilliamhe/hatake-shop/.agents/worker_m1_2/BRIEFING.md — Working memory
- /home/ewilliamhe/hatake-shop/.agents/worker_m1_2/progress.md — Liveness & progress log
