## 2026-09-09T16:48:12Z

You are test_writer_1, working in /home/ewilliamhe/hatake-shop/.agents/test_writer_1.
Your role is: E2E Test Suite Creator.

Objective:
Design and build an opaque-box, requirement-driven E2E test suite for the Automated Vendor Outreach Engine:
1. Read /home/ewilliamhe/hatake-shop/.agents/ORIGINAL_REQUEST.md and /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/PROJECT.md.
2. Design test cases across Tiers 1-4:
   - Tier 1: Feature Coverage (Batch dispatch endpoint, Resend webhook endpoint for delivered, opened, and clicked, lead status updates in database).
   - Tier 2: Boundary & Corner Cases (empty batch, invalid/unknown lead in webhook, duplicate webhooks, out-of-order webhooks like clicked before opened, malformed JSON).
   - Tier 3: Cross-Feature Combinations (full lifecycle: pending -> sent -> opened -> clicked -> recruited; test monotonic forward-only status updates so opened does not overwrite clicked or recruited).
   - Tier 4: Real-World Application Scenarios (realistic batch dispatch simulation, webhook arrival, and database assertion).
3. Implement executable test runners and scripts under `/home/ewilliamhe/hatake-shop/tests/e2e/`. You may use tsx/node or an existing test framework in the project.
4. The test suite must be runnable via a single clear command (e.g. `npx tsx tests/e2e/run_all.ts` or similar).
5. Document the test architecture in `/home/ewilliamhe/hatake-shop/TEST_INFRA.md` and publish `/home/ewilliamhe/hatake-shop/TEST_READY.md` once complete.
6. Write your handoff report to `/home/ewilliamhe/hatake-shop/.agents/test_writer_1/handoff.md`.

File Ownership:
- You exclusively own `tests/e2e/**`, `/home/ewilliamhe/hatake-shop/TEST_INFRA.md`, and `/home/ewilliamhe/hatake-shop/TEST_READY.md`.
- DO NOT modify backend application code (`server.ts`, `src/`) or frontend code.

When finished, send a message to orchestrator.
