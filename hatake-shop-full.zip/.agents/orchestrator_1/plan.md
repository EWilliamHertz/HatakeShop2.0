# Master Execution Plan: Automated Vendor Outreach Engine

## Task Overview
Build an Automated Vendor Outreach Engine allowing admins to manually dispatch personalized, branded emails to batches of 50 TCG vendors containing unique Hatake invite links using the Resend API, with webhook tracking for 'delivered', 'opened', 'clicked' statuses in real-time, and enhanced Admin Leads UI displaying the full funnel:
Pending -> Sent -> Opened -> Clicked -> Recruited.

## Phases
1. **Phase 0: Architecture & Codebase Survey**
   - Dispatch 3 parallel Explorers:
     - Explorer 1: Backend architecture, server.ts, API routes, database schema (leads table, postgres migration setup, ORM/query builder).
     - Explorer 2: Frontend architecture, Admin Leads UI component, state management, API client, funnel display.
     - Explorer 3: Resend SDK integration feasibility, email template structure/branding, webhook payload format and security/signature handling, environment variables.
   - Aggregate survey findings and construct `PROJECT.md` (Architecture, Feature Inventory, Milestones, Code Layout, Interfaces).

2. **Phase 1: Dual Track Launch**
   - E2E Testing Track: Launch E2E Test Writer / Harness setup to define Tier 1-4 tests and `TEST_INFRA.md`.
   - Milestone 1: Resend SDK Integration & Batch Dispatch Endpoint (`POST /api-v2/leads/dispatch-batch` or similar).

3. **Phase 2: Milestone 2 - Webhook Tracking & Database Updates**
   - Webhook endpoint (`POST /api-v2/webhooks/resend`) with validation, Resend event processing ('delivered', 'opened', 'clicked').
   - Updating `leads` table statuses and metadata.

4. **Phase 3: Milestone 3 - Frontend Admin Leads UI & Funnel**
   - "Send Next 50 Invites" button with loading/feedback states and error handling.
   - Full funnel visualization: Pending -> Sent -> Opened -> Clicked -> Recruited.
   - Live updates / polling or UI sync.

5. **Phase 4: Final Milestone - E2E Test Suite & Adversarial Hardening**
   - Verification of 100% E2E test suite (Tiers 1-4).
   - Adversarial coverage hardening (Tier 5) with Challengers and Forensic Auditor.
   - Final review and reporting.
