# Project: Automated Vendor Outreach Engine & Tracking Funnel

## Architecture
- **Backend**: Express 4.21 with Socket.IO in `server.ts`.
  - Endpoint `POST /api-v2/admin/leads/send`: Batch email dispatch using Resend SDK with configured credentials (`b2b@hatake.social`, `ernst@hatake.eu`).
  - Endpoint `POST /api-v2/webhooks/resend`: Webhook receiver for Resend events (`email.delivered`, `email.opened`, `email.clicked`), supporting both `curl` test simulation and live webhooks.
  - Real-time event broadcasting: `io.emit("lead_updated", { leadId, status, openedAt, clickedAt })`.
- **Database**: Neon Postgres via Drizzle ORM (`src/db/schema.ts`, `src/db/index.ts`).
  - Table `leads`: Add `status` enum values (`opened`, `clicked`), add `clicked_at: timestamp`, `resend_email_id: text`.
- **Frontend**: React 19 + Vite 6 + Tailwind CSS v4 in `src/pages/AdminDashboard.tsx`.
  - "Send Next 50 Invites" button with loading state, confirmation, disabled when 0 pending leads, and Sonner toasts.
  - 5-stage Funnel visualizer: Pending → Sent → Opened → Clicked → Recruited.
  - Color-coded status badges and status filters (`opened`, `clicked`).
  - Real-time updates via Socket.IO + 15s fallback polling.
- **E2E Testing Track**: Independent opaque-box test runner covering Tiers 1-4 with simulated curl Resend webhooks, admin batch dispatch verification, and database state assertions.

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| 1 | Resend SDK Credentials Config | Configure `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `RESEND_REPLY_TO` in `.env` and `server.ts` | M1 | ORIGINAL_REQUEST §R1 |
| 2 | Leads Schema & Migration | Update `leads.status` enum (`opened`, `clicked`), add `clicked_at` and `resend_email_id` columns in DB and Drizzle schema | M1 | ORIGINAL_REQUEST §R2 |
| 3 | Batch Outreach Dispatch Endpoint | Update `POST /api-v2/admin/leads/send` with Resend SDK, branding, tokens, tags, and response handling | M1 | ORIGINAL_REQUEST §R1 |
| 4 | Resend Webhook Endpoint | Expose `POST /api-v2/webhooks/resend` for delivered, opened, clicked events with forward-only status updates | M1 | ORIGINAL_REQUEST §R2 |
| 5 | Lead Metrics Fix | Update `sentCount` queries in `server.ts` to count all contacted leads (`status != 'pending'`) | M1 | Survey Explorer 1 |
| 6 | Admin "Send Next 50 Invites" Button | Add/upgrade button in Admin Leads UI with loading, feedback, and error handling | M2 | ORIGINAL_REQUEST §R1 |
| 7 | Full Funnel Tracking UI | 5-stage Funnel visualizer (Pending → Sent → Opened → Clicked → Recruited), badges, and filters in Admin Leads UI | M2 | ORIGINAL_REQUEST §R3 |
| 8 | Real-Time UI Sync | Socket.IO event listener + 15s polling fallback for instant lead status updates | M2 | ORIGINAL_REQUEST §R3 |
| 9 | Comprehensive E2E Testing Suite | Multi-tier test suite covering batch dispatch, webhook processing, and database verification | M3 | ORIGINAL_REQUEST §Acceptance Criteria |

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| M1 | Backend Outreach & Webhook Engine | `src/db/schema.ts`, DB migration, `.env`, `server.ts` endpoints (`/api-v2/admin/leads/send`, `/api-v2/webhooks/resend`), Socket.IO | none | IN_PROGRESS |
| M2 | Frontend Admin Leads Funnel UI | `src/pages/AdminDashboard.tsx`, button, funnel header, badges, filter, socket sync | M1 | PLANNED |
| M3 | Final E2E Test Pass & Hardening | Full verification (Tiers 1-4), adversarial tests (Tier 5), forensic audit | M1, M2 | PLANNED |

## Interface Contracts
### Admin Dispatch: Frontend ↔ Backend
- **Endpoint**: `POST /api-v2/admin/leads/send`
- **Headers**: `Authorization: Bearer <token>`, `Content-Type: application/json`
- **Request Body**: `{ "limit": 50 }`
- **Response**: `{ "success": true, "sent": number, "message": string }`
- **Error Response**: `{ "error": string }` (HTTP 400 / 500)

### Resend Webhook: Resend / Curl ↔ Backend
- **Endpoint**: `POST /api-v2/webhooks/resend`
- **Headers**: `Content-Type: application/json`
- **Request Body Format**:
  ```json
  {
    "type": "email.delivered" | "email.opened" | "email.clicked",
    "created_at": "2026-09-09T16:00:00.000Z",
    "data": {
      "email_id": "string",
      "from": "b2b@hatake.social",
      "to": ["vendor@example.com"],
      "subject": "string",
      "tags": { "lead_id": "123" },
      "click": { "link": "https://...", "timestamp": "..." }
    }
  }
  ```
- **Response**: HTTP 200 `{ "received": true, "leadId": number, "status": "opened" | "clicked" }`
- **State Monotonicity**:
  - `pending` (0) -> `sent` (1) -> `opened` (2) -> `clicked` (3) -> `recruited` (4)
  - An event can never downgrade a lead's stage. `recruited` is immutable.

### Real-Time Updates: Backend ↔ Frontend
- **Event**: `io.emit("lead_updated", { id: number, status: string, openedAt?: string, clickedAt?: string })`

## Code Layout
- `src/db/schema.ts` — Drizzle schema definition for `leads` table. Owned by M1.
- `.env` — Environment configuration. Owned by M1.
- `server.ts` — Express server, webhook route, dispatch logic, Socket.IO. Owned by M2.
- `src/pages/AdminDashboard.tsx` — Admin Leads UI component. Owned by M3.
- `tests/e2e/` — E2E test scripts and runners. Owned by E2E Testing Track / M4.
