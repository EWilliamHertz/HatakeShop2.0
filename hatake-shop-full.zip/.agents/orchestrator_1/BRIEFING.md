# BRIEFING — 2026-09-09T16:40:40Z

## Mission
Build an Automated Vendor Outreach Engine (Resend email dispatch, webhook tracking for opened/clicked, leads UI funnel).

## 🔒 My Identity
- Archetype: orchestrator
- Roles: orchestrator, user_liaison, human_reporter, successor
- Working directory: /home/ewilliamhe/hatake-shop/.agents/orchestrator_1
- Original parent: parent
- Original parent conversation ID: 97c45ed6-b886-44e7-af83-dee7efc552fe

## 🔒 My Workflow
- **Pattern**: Project
- **Scope document**: /home/ewilliamhe/hatake-shop/PROJECT.md
1. **Decompose**: Decompose full project scope across architectural boundaries into 3-7 milestones.
2. **Dispatch & Execute**:
   - **Direct (iteration loop)**: For each milestone: 3 Explorers -> 1 Worker -> 2 Reviewers + 2 Challengers + 1 Forensic Auditor -> Gate.
3. **On failure** (in this order):
   - Retry: nudge stuck agent or re-send task
   - Replace: spawn fresh agent with partial progress
   - Skip: proceed without (only if non-critical)
   - Redistribute: split stuck agent's remaining work
   - Redesign: re-partition decomposition
   - Escalate: report to parent (sub-orchestrators only, last resort)
4. **Succession**: At 16 spawns, write handoff.md, cancel timers, spawn successor.
- **Work items**:
  1. Survey & Architecture Mapping [done]
  2. E2E Testing Track: Test Infra & Suite Creation [in-progress]
  3. M1: Backend Outreach & Webhook Engine [in-progress]
  4. M2: Frontend Admin Leads Funnel UI [pending]
  5. M3: Final E2E Test Pass & Adversarial Hardening [pending]
- **Current phase**: 1 (Dual Track: M1 + E2E Testing Track)
- **Current focus**: Milestone 1 Backend Worker implementation & E2E Testing Suite setup

## 🔒 Key Constraints
- NEVER write, modify, or create source code files directly.
- NEVER run build/test commands yourself — require workers to do so.
- NEVER investigate or explore the problem at the code level — dispatch Explorers for technical investigation.
- You MAY use file-editing tools ONLY for metadata/state files (.md) in your .agents/ folder.
- Never reuse a subagent after it has delivered its handoff — always spawn fresh
- Binary veto: Forensic Auditor INTEGRITY VIOLATION fails milestone unconditionally.

## Current Parent
- Conversation ID: 97c45ed6-b886-44e7-af83-dee7efc552fe
- Updated: 2026-09-09T16:40:40Z

## Key Decisions Made
- Selected Project Pattern with Dual Track (Implementation + E2E Testing).
- Survey phase initiated with 3 parallel Explorers before milestone decomposition.

## Team Roster
| Agent | Type | Work Item | Status | Conv ID |
|-------|------|-----------|--------|---------|
| explorer_survey_1 | teamwork_preview_explorer | Survey Backend & Database | completed | bc6b3bef-0ddf-4e68-8e9e-49759959629b |
| explorer_survey_2 | teamwork_preview_explorer | Survey Frontend Admin UI | completed | 73c04e84-553f-427d-937b-113352fed067 |
| explorer_survey_3 | teamwork_preview_explorer | Survey Resend & Webhooks | completed | 07102028-3151-403d-bfd6-fc90b840e192 |
| test_writer_1 | teamwork_preview_test_writer | E2E Testing Suite Track | completed | ec09e5bb-3b4a-42b2-b0eb-0e8ca6fffecf |
| worker_m1_1 | teamwork_preview_worker | M1 Backend Outreach & Webhook | failed (stalled after restart) | caf367fd-bc39-4df2-ad19-12187a808678 |
| worker_m1_2 | teamwork_preview_worker | M1 Backend Outreach & Webhook | in-progress | 26e68c36-446f-4b5c-8c46-c75ae28b8627 |

## Succession Status
- Succession required: no
- Spawn count: 6 / 16
- Pending subagents: 26e68c36-446f-4b5c-8c46-c75ae28b8627
- Predecessor: none
- Successor: not yet spawned

## Active Timers
- Heartbeat cron: task-109
- Safety timer: none
- On succession: kill all timers before spawning successor
- On context truncation: run manage_task(Action="list") — re-create if missing

## Artifact Index
- /home/ewilliamhe/hatake-shop/.agents/ORIGINAL_REQUEST.md — User requirements
- /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/DISPATCH.md — Initial dispatch prompt
- /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/BRIEFING.md — Persistent working memory
- /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/plan.md — Orchestrator plan
- /home/ewilliamhe/hatake-shop/.agents/orchestrator_1/progress.md — Liveness & execution progress
