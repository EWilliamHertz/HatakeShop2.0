# Handoff Report — Frontend UI Explorer (explorer_survey_2)

**Report Path:** `/home/ewilliamhe/hatake-shop/.agents/explorer_survey_2/handoff.md`  
**Related Full Analysis:** `/home/ewilliamhe/hatake-shop/.agents/explorer_survey_2/analysis.md`  
**Date:** 2026-09-09T16:46:15Z

---

## 1. Observation

1. **Frontend Tooling and Dependencies (`package.json`):**
   - React 19 (`"react": "^19.0.1"`, `"react-dom": "^19.0.1"`).
   - Vite 6 (`"vite": "^6.2.3"`), `@vitejs/plugin-react: ^5.0.4`.
   - Routing: `"react-router-dom": "^7.18.2"`.
   - Styling: `"tailwindcss": "^4.1.14"`, `"@tailwindcss/vite": "^4.1.14"`, `"clsx": "^2.1.1"`, `"tailwind-merge": "^3.6.0"`.
   - Icons: `"lucide-react": "^0.546.0"`.
   - UI / Feedback: `"sonner": "^2.0.8"` mounted in `src/App.tsx:58` (`<Toaster position="top-center" richColors />`), `"framer-motion": "^11.18.2"`, `"recharts": "^3.10.1"`.
   - Real-time & Data Fetching: `"@tanstack/react-query": "^5.102.2"`, `"socket.io-client": "^4.8.3"`.
   - CSV Parsing: `"papaparse": "^5.7.0"`.

2. **Admin Leads UI Location and Access (`src/App.tsx`, `src/components/Layout.tsx`, `src/pages/AdminDashboard.tsx`):**
   - Route in `src/App.tsx` (lines 76–80):
     ```tsx
     <Route path="/admin" element={
       <ProtectedRoute requireAdmin>
         <ErrorBoundary><AdminDashboard /></ErrorBoundary>
       </ProtectedRoute>
     } />
     ```
   - Navigation Link in `src/components/Layout.tsx` (lines 244–252): Admin link displayed in footer when `dbUser?.role === 'admin'`.
   - Admin Tab in `src/pages/AdminDashboard.tsx` (lines 400–409):
     `['overview', 'approvals', 'users', 'marketing', 'affiliates', 'leads', 'feedback']`.
   - Leads UI Render Block in `src/pages/AdminDashboard.tsx` (lines 835–998):
     `{activeTab === 'leads' && ( ... )}`.
   - Note on `src/pages/Leads.tsx`: Route `/leads` renders public directory calling `/api-v2/public/partners`, not the admin outreach engine.

3. **Data Fetching and State (`src/pages/AdminDashboard.tsx`, `server.ts`):**
   - State variables (lines 159–166):
     ```ts
     const [leads, setLeads] = useState([]);
     const [leadFilter, setLeadFilter] = useState('all');
     const [segmentFilter, setSegmentFilter] = useState('all');
     const [sentCount, setSentCount] = useState(0);
     const [uploading, setUploading] = useState(false);
     const [previewingHtml, setPreviewingHtml] = useState<string | null>(null);
     const [sending, setSending] = useState(false);
     ```
   - Request in `fetchAdminData()` (lines 207–208):
     Calls `GET /api-v2/admin/leads` with `Authorization: Bearer ${token}`.
   - Server handler in `server.ts` (lines 484–495):
     Returns `{ leads: allLeads, sentCount: Number(sentCount[0].count) }`.

4. **Existing Dispatch Button and Badge Styling (`src/pages/AdminDashboard.tsx`):**
   - Dispatch Button (lines 905–925):
     ```tsx
     <button disabled={sending} onClick={async () => {
       if (!confirm('Send 50 emails now?')) return;
       setSending(true);
       try {
           let token; try { token = await user?.getIdToken(); } catch(e:any) { throw new Error("Firebase Auth Error: " + e.message); }
           const pendingIds = leads.filter((l:any) => l.status === 'pending' || !l.status).slice(0, 50).map((l:any) => l.id);
           if(pendingIds.length === 0) { toast.error('No pending leads.'); setSending(false); return; }
           await fetch('/api-v2/admin/leads/send', {
             method: 'POST',
             headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
             body: JSON.stringify({ limit: 50 })
           });
           fetchAdminData();
       } finally {
           setSending(false);
       }
     }} className="px-4 py-2 bg-ink text-white font-semibold tracking-tight rounded-xl hover:bg-ink-light w-full">
       {sending ? 'Sending...' : 'Send 50 Mails'}
     </button>
     ```
   - Badge styling (lines 974–976):
     ```tsx
     <span className={`px-2 py-1 rounded-full text-xs font-semibold tracking-tight ${
       lead.status === 'recruited' ? 'bg-emerald-50 text-emerald-700' : 
       lead.status === 'sent' ? 'bg-blue-50 text-blue-700' : 
       'bg-slate-900 text-slate-400'
     }`}>
       {(lead.status || 'pending').toUpperCase()}
     </span>
     ```
   - Verbatim Observation: Neither `'opened'` nor `'clicked'` statuses are handled in the status badge or the `leadFilter` dropdown. No funnel visualization exists in the UI.

5. **Existing Socket.io Integration:**
   - Server initializes `io = new Server(server, ...)` in `server.ts:15`.
   - Client imports `import { io } from 'socket.io-client'` in `VideoTour.tsx`, `RFQHub.tsx`, and `RFQDetails.tsx`.

---

## 2. Logic Chain

1. **Routing & Context Boundary:**
   - From Observation 2, `src/pages/AdminDashboard.tsx` is the sole administrative UI container for leads outreach (`activeTab === 'leads'`), gated by `ProtectedRoute requireAdmin`. All UI modifications must be made either inside `AdminDashboard.tsx` or as subcomponents imported into it.
2. **Dispatch Button Alignment:**
   - From Observation 4, the existing button is labeled "Send 50 Mails", uses browser `confirm()`, lacks HTTP error validation on `res.ok`, and has no `toast.success` showing the actual `data.sent` count.
   - Therefore, replacing this button with a dedicated "Send Next 50 Invites" button featuring loading indicators, a styled confirmation modal, disabled state when `pendingCount === 0`, and Sonner toast notifications will satisfy Requirement R1 and acceptance criteria.
3. **Tracking Dashboard & Funnel Requirement:**
   - From Observation 4, the current table only distinguishes `recruited`, `sent`, and default slate (`pending`). It completely ignores `opened` and `clicked` tracking states.
   - In accordance with Requirement R3 (Pending → Sent → Opened → Clicked → Recruited):
     - An aggregate Funnel Overview card must be placed at the top of the Leads tab, computing counts and conversion rates across the 5 stages.
     - The Table rows must render distinct color badges for all 5 stages (`pending`: slate, `sent`: blue, `opened`: amber, `clicked`: purple, `recruited`: emerald) plus a mini-step funnel milestone indicator.
     - The filter dropdown must include options for `opened` and `clicked`.
4. **Real-Time Update Strategy:**
   - From Observation 5, `socket.io-client` is already in the project. Connecting `socket.io` in `AdminDashboard.tsx` when `activeTab === 'leads'` listening for a `lead_status_updated` event emitted by the Resend webhook handler, backed by a 15-second polling interval fallback, fulfills the real-time update requirement reliably.

---

## 3. Caveats

1. **PostgreSQL Service State in Local Environment:**
   Running `npx tsx check_leads.ts` encountered `ECONNREFUSED 127.0.0.1:5432` because local postgres is either paused or requires Cloud SQL / Docker configuration in this container. Frontend mock auth (`mock-admin-token`) and client builds run independently.
2. **Single Existing TypeScript Lint Error in `vite.config.ts`:**
   Running `npm run lint` failed solely on `vite.config.ts:7` due to Vite 6 typing for `allowedHosts: true`. The frontend source files in `src/` have zero type errors.
3. **Database Schema Dependency:**
   The frontend can render `openedAt` and `clickedAt` and `status` values seamlessly, but the backend migration must ensure the `leads` table enum/column supports `opened` and `clicked` and `clickedAt`.

---

## 4. Conclusion

The frontend architecture and Admin Leads UI have been completely mapped. The implementation path for the UI is clear, low-risk, and requires no new external dependencies:
1. Modify `/home/ewilliamhe/hatake-shop/src/pages/AdminDashboard.tsx` (or extract an `AdminLeadsFunnel.tsx` component).
2. Upgrade the dispatch button to "Send Next 50 Invites" with clean confirmation, loading spinners, and Sonner notifications.
3. Implement the 5-stage funnel visualization (Pending → Sent → Opened → Clicked → Recruited) at both the pipeline summary level and individual lead row level.
4. Add real-time event handling via Socket.io with a 15s polling fallback.

---

## 5. Verification Method

1. **Static Typecheck:**
   Run `npm run lint` (`tsc --noEmit`) to verify there are no TypeScript syntax or type mismatch errors in `src/pages/AdminDashboard.tsx`.
2. **Frontend Build:**
   Run `npm run build` (`vite build`) to ensure all components, Tailwind v4 utility styles, Lucide icons, and Sonner toasts compile cleanly.
3. **Visual & Behavioral Inspection:**
   - Access `/admin` in the browser with admin credentials or `mock-admin-token`.
   - Click the "leads" tab.
   - Verify the "Send Next 50 Invites" button triggers `/api-v2/admin/leads/send` and responds with toast notifications.
   - Verify the 5-stage Funnel header renders counts and conversion percentages.
   - Verify table rows render badges for `PENDING`, `SENT`, `OPENED`, `CLICKED`, and `RECRUITED`.
   - Test filtering by each of the 5 statuses.
