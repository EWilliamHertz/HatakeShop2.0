# Frontend Architecture & Admin Leads UI Investigation Report

**Investigation Date:** 2026-09-09  
**Investigator:** explorer_survey_2 (Frontend UI Explorer)  
**Target Repository:** `/home/ewilliamhe/hatake-shop`

---

## 1. Executive Summary

This investigation analyzed the frontend codebase of Hatake.Shop with particular focus on the Admin Leads UI, email dispatch controls, tracking dashboard requirements, and real-time update infrastructure. 

Key discoveries:
1. **Frontend Stack:** React 19 (`19.0.1`), Vite 6 (`6.2.3`), React Router v7 (`7.18.2`), Tailwind CSS v4 (`@tailwindcss/vite`), Lucide React icons (`0.546.0`), and Sonner (`2.0.8`) for toasts.
2. **Admin Leads UI Location:** Located inside `/home/ewilliamhe/hatake-shop/src/pages/AdminDashboard.tsx` rendered when `activeTab === 'leads'` (lines 835–998). Protected by `<ProtectedRoute requireAdmin>` on route `/admin`. (Note: `/leads` maps to `src/pages/Leads.tsx`, which is a public partner directory, NOT the admin outreach engine).
3. **Current Leads State & Capabilities:**
   - Data fetching via `fetchAdminData()` calling `GET /api-v2/admin/leads`.
   - Table displays leads with segment and status filters (`to-send`, `recruited`, `sent`, `all`).
   - Status badge only has explicit styling for `'recruited'` and `'sent'`—`'opened'` and `'clicked'` fall back to generic slate.
   - An existing dispatch button ("Send 50 Mails") exists at line 923, triggering `POST /api-v2/admin/leads/send`, but uses raw `window.confirm`, lacks proper error/success toast messaging, and needs alignment with prompt requirements ("Send Next 50 Invites").
   - There is NO funnel visualization currently implemented.
4. **Integration Ready:** Both Socket.io (`socket.io-client: ^4.8.3`) and TanStack Query (`@tanstack/react-query: ^5.102.2`) are installed and active in the project, providing immediate pathways for real-time funnel updates via webhook-triggered WebSocket events and polling fallbacks.

---

## 2. Frontend Architecture & Technology Stack

### 2.1 Core Framework & Tooling
| Layer | Technology | Version | Details & Config |
|---|---|---|---|
| Framework | **React** | `^19.0.1` | React 19 functional components with hooks |
| Build Tool | **Vite** | `^6.2.3` | Configured in `vite.config.ts` with React & Tailwind plugins |
| Routing | **React Router DOM** | `^7.18.2` | Configured in `src/App.tsx` (`BrowserRouter`, `Routes`, `Route`) |
| CSS System | **Tailwind CSS v4** | `^4.1.14` | Configured via `@tailwindcss/vite` and `@theme` in `src/index.css` |
| CSS Helpers | `clsx` / `tailwind-merge` | `^2.1.1` / `^3.6.0` | Helper `cn()` in `src/components/Layout.tsx` |
| Icons | **Lucide React** | `^0.546.0` | Primary icon package (`Send`, `Mail`, `CheckCircle`, `Clock`, etc.) |
| Toast / Notifications | **Sonner** | `^2.0.8` | Mounted in `App.tsx:58` (`<Toaster position="top-center" richColors />`); called via `toast.success()`, `toast.error()` |
| Animation | **Framer Motion** | `^11.18.2` | Smooth transitions and state animations |
| Charts | **Recharts** | `^3.10.1` | Available for metric charts |
| Data Fetching / Cache | **TanStack React Query** | `^5.102.2` | `<QueryClientProvider>` configured in `App.tsx:57` |
| Real-time WebSockets | **Socket.io Client** | `^4.8.3` | Used across `VideoTour.tsx`, `RFQHub.tsx`, and `RFQDetails.tsx` |
| CSV Parsing | **PapaParse** | `^5.7.0` | Used in `AdminDashboard.tsx` for CSV upload |
| i18n | **react-i18next** | `^17.0.13` | Multi-language translation support |

### 2.2 Styling System & Color Palette
Tailwind v4 is configured in `src/index.css` with dark theme design tokens:
- `--color-canvas: #020617;` (slate-950)
- `--color-surface: #0f172a;` (slate-900)
- `--color-surface-hover: #1e293b;` (slate-800)
- `--color-ink: #e2e8f0;` (slate-200)
- `--color-ink-light: #94a3b8;` (slate-400)
- `--color-hairline: #1e293b;` (slate-800)
- `--color-accent: #06b6d4;` (cyan-500)
- Accent brand color: `#ffcc00` (gold/yellow used for highlights and badges)
- Custom utility classes: `.panel`, `.btn-primary`, `.btn-secondary`, `.input-modern`, `.heading-xl`, `.heading-lg`, `.heading-md`.

---

## 3. Admin Leads UI Location, Routing & Access Control

### 3.1 Route Hierarchy
- **Route Definition (`src/App.tsx`, lines 76–80):**
  ```tsx
  <Route path="/admin" element={
    <ProtectedRoute requireAdmin>
      <ErrorBoundary><AdminDashboard /></ErrorBoundary>
    </ProtectedRoute>
  } />
  ```
- **Access Control (`src/App.tsx`, lines 32–51):**
  `ProtectedRoute` inspects `dbUser?.role`. If `requireAdmin` is true and `dbUser?.role !== 'admin'`, user is redirected to `/`.
  In `src/components/AuthContext.tsx`, admins are identified by email (`ernst@hatake.eu`, `ewilliamhe@gmail.com`, `phoebe@topbestpkg.com`), or fallback token `mock-admin-token`.
- **Navigation Access (`src/components/Layout.tsx`, lines 244–252):**
  In the layout footer:
  ```tsx
  {dbUser?.role === 'admin' && (
    <>
      <div className="w-px h-4 bg-slate-300"></div>
      <Link to="/admin" className="flex items-center space-x-2 text-slate-400 hover:text-slate-100 font-semibold transition-colors">
        <Shield className="w-4 h-4" />
        <span>{t('Admin')}</span>
      </Link>
    </>
  )}
  ```
- **Distinction from `/leads` (`src/pages/Leads.tsx`):**
  `/leads` renders a public vendor showcase fetching `/api-v2/public/partners`. The administrative vendor outreach engine resides exclusively inside `/admin` under `activeTab === 'leads'` in `src/pages/AdminDashboard.tsx`.

### 3.2 Tab Navigation in `AdminDashboard.tsx`
- Line 150: `const [activeTab, setActiveTab] = useState('overview');`
- Line 400: Navigation buttons list `['overview', 'approvals', 'users', 'marketing', 'affiliates', 'leads', 'feedback']`.
- Line 835: `{activeTab === 'leads' && ( ... )}` renders the Leads management view.

---

## 4. Current Admin Leads Implementation Analysis

### 4.1 State Management in `AdminDashboard.tsx`
The leads section relies on local React component state (lines 159–166):
```ts
const [leads, setLeads] = useState<any[]>([]);
const [leadFilter, setLeadFilter] = useState('all');       // 'all' | 'to-send' | 'recruited' | 'sent'
const [segmentFilter, setSegmentFilter] = useState('all'); // 'all' | 'TCG' | 'Sports' | 'General'
const [sentCount, setSentCount] = useState(0);             // Count of sent leads
const [uploading, setUploading] = useState(false);         // CSV uploading flag
const [previewingHtml, setPreviewingHtml] = useState<string | null>(null); // Template preview modal HTML
const [sending, setSending] = useState(false);             // Email batch dispatch in progress
```

### 4.2 Data Fetching Call & Endpoint
- **Function:** `fetchAdminData()` (lines 177–219)
- **Token Handling:**
  ```ts
  let token = await user?.getIdToken();
  const headers = { 'Authorization': `Bearer ${token}` };
  ```
- **Request:** `GET /api-v2/admin/leads`
- **Backend Response (`server.ts`, lines 484–495):**
  ```ts
  {
    leads: Lead[],      // Array of leads ordered by createdAt desc
    sentCount: number   // Count of leads where status = 'sent'
  }
  ```
- **Frontend Handler:**
  ```ts
  const leadsData = await safeFetch('/api-v2/admin/leads');
  if (leadsData) { 
    setLeads(leadsData.leads); 
    setSentCount(leadsData.sentCount); 
  }
  ```

### 4.3 Existing UI Layout & Component Structure
The current Leads UI inside `AdminDashboard.tsx` (lines 835–998) is split into two major sections:

#### Top Metric & Action Cards (`grid grid-cols-1 md:grid-cols-2 gap-6`, lines 837–927)
1. **Pipeline Metric Card (Left):**
   - Title: "B2B Outreach Pipeline (Smartlead/Instantly)"
   - Number: `{sentCount} / 20,000`
   - Progress bar: `width: ${Math.min(50, (sentCount / 20000) * 50)}%`
   - Status notes: "Limit: 50 emails/day/inbox for deliverability health."
2. **Batch Controls Card (Right):**
   - Title: "Export Next Batch (50) to CRM"
   - CSV Uploader: "Upload CSV (.csv)" using `Papa.parse` and POSTing to `/api-v2/admin/leads/upload`.
   - Preview Button: Calls `GET /api-v2/admin/leads/preview` and opens full-screen `iframe` modal (`previewingHtml`).
   - Dispatch Button: Currently labeled `"Send 50 Mails"` (lines 905–925).

#### Lead Database Table Card (lines 929–995)
- **Filter Bar:**
  - `segmentFilter`: All Segments, TCG, Sports, General.
  - `leadFilter`: To-Send (Pending), Recruited, Sent (Not Recruited), All Status.
- **Table Columns:**
  1. Company (`lead.companyName || 'N/A'`)
  2. Segment (`lead.segment || 'TCG'`)
  3. Email (`lead.email`)
  4. Website (`lead.website ? <a ...>Link</a> : '-'`)
  5. Status Badge:
     ```tsx
     <span className={`px-2 py-1 rounded-full text-xs font-semibold tracking-tight ${
       lead.status === 'recruited' ? 'bg-emerald-50 text-emerald-700' : 
       lead.status === 'sent' ? 'bg-blue-50 text-blue-700' : 
       'bg-slate-900 text-slate-400'
     }`}>
       {(lead.status || 'pending').toUpperCase()}
     </span>
     ```
  6. Actions:
     - If `lead.status !== 'recruited'`: "Mark Recruited" button calling `handleUpdateLeadStatus(lead.id, 'recruited')`.
     - If `lead.status === 'recruited'`: "Undo" button calling `handleUpdateLeadStatus(lead.id, 'pending')`.

### 4.4 Missing Functionality in Current Implementation
1. **Statuses Not Handled:** Only `'recruited'`, `'sent'`, and default (`'pending'`) are styled. `'opened'` and `'clicked'` have NO badge styling (displaying as generic dark slate `bg-slate-900 text-slate-400`).
2. **Filtering Gaps:** `leadFilter` dropdown has no options for `'opened'` or `'clicked'`.
3. **No Funnel Tracking:** There is no visual funnel representing the 5 states (`Pending → Sent → Opened → Clicked → Recruited`) either at the aggregate level or per vendor.
4. **Button UX Defects:**
   - Button text is `"Send 50 Mails"` rather than `"Send Next 50 Invites"`.
   - Uses browser `window.confirm('Send 50 emails now?')`.
   - Does not check `res.ok` or display `toast.success` with `data.sent`.
   - Has no `catch` block to surface HTTP failures with `toast.error`.
5. **No Pagination or Search:** All leads are dumped into the DOM without pagination or text search.

---

## 5. Integration Plan: "Send Next 50 Invites" Button

### 5.1 Placement & Alignment
- **Location:** `src/pages/AdminDashboard.tsx`, inside the Batch Controls card (replacing lines 905–925).
- **Label:** `"Send Next 50 Invites"` (or `"Sending 50 Invites..."` while loading).
- **Visual Design:**
  - Primary button with icon: `<Send className="w-4 h-4 mr-2" />`
  - Style: `bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-cyan-500/20 px-4 py-2.5 flex items-center justify-center w-full`
  - Subtitle / badge indication: Show count of available pending leads: `({pendingCount} pending available)`.

### 5.2 Confirmation Modal & User Flow
Rather than browser-native `confirm()`, implement an accessible confirmation modal or inline state:
1. When user clicks "Send Next 50 Invites", show confirmation modal:
   - Header: "Dispatch B2B Vendor Invites"
   - Body: "You are about to dispatch personalized Resend invitation emails to the next 50 pending leads. This action cannot be undone."
   - Target metrics: e.g. "Pending leads queue: {pendingCount} | Batch limit: 50".
   - Actions: "Cancel" (secondary) and "Confirm & Send 50 Invites" (primary).

### 5.3 Request Execution & Error Handling
```ts
const handleSendNext50Invites = async () => {
  setSending(true);
  try {
    let token = await user?.getIdToken();
    const res = await fetch('/api-v2/admin/leads/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ limit: 50 })
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Server returned ${res.status}`);
    }

    const data = await res.json();
    toast.success(`Successfully dispatched ${data.sent} invite emails via Resend!`);
    await fetchAdminData();
  } catch (error: any) {
    console.error("Failed to send invites:", error);
    toast.error(error.message || 'Failed to dispatch invites');
  } finally {
    setSending(false);
  }
};
```

### 5.4 Disabled States
- Disabled if `sending === true`.
- Disabled if `pendingCount === 0`.
- Tooltip or helper text: "No pending leads to send. Upload new leads via CSV above."

---

## 6. Integration Plan: Full Funnel Visualization

Requirement R3: **"Enhance the existing Admin 'Leads' UI to visually display the full funnel of tracking states for each vendor: Pending → Sent → Opened → Clicked → Recruited."**

### 6.1 Funnel State Progression Definition
Each vendor progresses through 5 hierarchical states:
```
[1. PENDING] ──(Dispatched via Resend)──> [2. SENT] ──(Email Opened)──> [3. OPENED] ──(Link Clicked)──> [4. CLICKED] ──(Registered/Onboarded)──> [5. RECRUITED]
```

Corresponding timestamps in database:
- `createdAt` (Pending)
- `sentAt` (Sent)
- `openedAt` (Opened)
- `clickedAt` (Clicked - *database column added in backend schema*)
- `redeemedAt` / updated (Recruited)

### 6.2 Component 1: Aggregate Funnel Dashboard (Header Component)
Place a high-impact horizontal Funnel Pipeline at the top of the Leads tab (above the database table):

```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│  B2B OUTREACH FUNNEL                                                                                  │
│                                                                                                        │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐     │
│  │   PENDING    │ ─> │     SENT     │ ─> │    OPENED    │ ─> │   CLICKED    │ ─> │  RECRUITED   │     │
│  │     120      │    │     180      │    │      72      │    │      36      │    │      18      │     │
│  │  In queue    │    │ (Dispatched) │    │  40.0% Open  │    │ 50.0% Click  │    │  50.0% Conv  │     │
│  └──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘     │
└────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

#### Calculated Funnel Metrics:
- **Pending:** `leads.filter(l => l.status === 'pending' || !l.status).length`
- **Sent:** `leads.filter(l => ['sent', 'opened', 'clicked', 'recruited'].includes(l.status)).length`
- **Opened:** `leads.filter(l => ['opened', 'clicked', 'recruited'].includes(l.status)).length`
- **Clicked:** `leads.filter(l => ['clicked', 'recruited'].includes(l.status)).length`
- **Recruited:** `leads.filter(l => l.status === 'recruited').length`
- **Conversion Rates:**
  - Open Rate = `(Opened / Sent) * 100%`
  - CTR (Click-to-Open) = `(Clicked / Opened) * 100%`
  - Recruitment Rate = `(Recruited / Clicked) * 100%`

#### Interactive Stage Filtering:
Clicking any stage card sets `leadFilter` to that stage, instantly filtering the table below.

### 6.3 Component 2: Per-Vendor Row Funnel Stepper
In the database table:
1. **Enhanced Status Badge:**
   ```tsx
   const STATUS_CONFIG: Record<string, { label: string; badgeClass: string; dotClass: string }> = {
     pending: {
       label: 'PENDING',
       badgeClass: 'bg-slate-700/50 text-slate-300 border border-slate-600',
       dotClass: 'bg-slate-400'
     },
     sent: {
       label: 'SENT',
       badgeClass: 'bg-blue-500/10 text-blue-400 border border-blue-500/20',
       dotClass: 'bg-blue-400'
     },
     opened: {
       label: 'OPENED',
       badgeClass: 'bg-amber-500/10 text-amber-400 border border-amber-500/20',
       dotClass: 'bg-amber-400'
     },
     clicked: {
       label: 'CLICKED',
       badgeClass: 'bg-purple-500/10 text-purple-400 border border-purple-500/20',
       dotClass: 'bg-purple-400'
     },
     recruited: {
       label: 'RECRUITED',
       badgeClass: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
       dotClass: 'bg-emerald-400'
     },
     failed: {
       label: 'FAILED',
       badgeClass: 'bg-rose-500/10 text-rose-400 border border-rose-500/20',
       dotClass: 'bg-rose-400'
     }
   };
   ```
2. **Visual Funnel Progress Stepper Column:**
   Add a dedicated "Funnel Stage" column showing a 5-step milestone track for each vendor:
   ```tsx
   function VendorFunnelTrack({ status, sentAt, openedAt, clickedAt, redeemedAt }: any) {
     const stages = [
       { key: 'pending', label: 'Pending', active: true },
       { key: 'sent', label: 'Sent', active: ['sent', 'opened', 'clicked', 'recruited'].includes(status), date: sentAt },
       { key: 'opened', label: 'Opened', active: ['opened', 'clicked', 'recruited'].includes(status), date: openedAt },
       { key: 'clicked', label: 'Clicked', active: ['clicked', 'recruited'].includes(status), date: clickedAt },
       { key: 'recruited', label: 'Recruited', active: status === 'recruited', date: redeemedAt },
     ];

     return (
       <div className="flex items-center space-x-1">
         {stages.map((st, i) => (
           <React.Fragment key={st.key}>
             <div 
               title={`${st.label}${st.date ? ` (${new Date(st.date).toLocaleDateString()})` : ''}`}
               className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                 st.active ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-slate-800 text-slate-600 border border-slate-700'
               }`}
             >
               {i + 1}
             </div>
             {i < stages.length - 1 && (
               <div className={`w-3 h-0.5 ${stages[i+1].active ? 'bg-cyan-500/50' : 'bg-slate-700'}`} />
             )}
           </React.Fragment>
         ))}
       </div>
     );
   }
   ```

### 6.4 Enhanced Filter Controls
Update the `leadFilter` `<select>`:
- `all`: "All Statuses"
- `pending`: "Pending (To Send)"
- `sent`: "Sent"
- `opened`: "Opened"
- `clicked`: "Clicked"
- `recruited`: "Recruited"
- `failed`: "Failed"

---

## 7. Real-Time Update Mechanism

### 7.1 WebSocket (Socket.io) Architecture
The repository already has `socket.io` installed on the server and `socket.io-client` on the client.
- **Server:** `server.ts` creates `const io = new Server(server, ...)`.
- **Webhook Trigger (`server.ts`):**
  When Resend webhook `/api-v2/webhooks/resend` handles `email.opened` or `email.clicked`:
  ```ts
  io.emit('lead_status_updated', {
    leadId: lead.id,
    email: lead.email,
    status: newStatus,
    timestamp: new Date()
  });
  ```
- **Frontend Integration (`AdminDashboard.tsx`):**
  ```tsx
  useEffect(() => {
    if (activeTab !== 'leads') return;

    const socket = io();
    
    socket.on('lead_status_updated', (data: { leadId: number; status: string; timestamp: string }) => {
      setLeads(prev => prev.map(l => {
        if (l.id === data.leadId) {
          const updated = { ...l, status: data.status };
          if (data.status === 'opened') updated.openedAt = data.timestamp;
          if (data.status === 'clicked') updated.clickedAt = data.timestamp;
          return updated;
        }
        return l;
      }));
      toast.info(`Lead update: ${data.status.toUpperCase()} event received!`);
    });

    return () => {
      socket.disconnect();
    };
  }, [activeTab]);
  ```

### 7.2 Polling Fallback
In case WebSockets are interrupted by proxy/firewalls:
```tsx
useEffect(() => {
  if (activeTab !== 'leads') return;
  const interval = setInterval(() => {
    fetchAdminData();
  }, 15000); // 15s polling interval
  return () => clearInterval(interval);
}, [activeTab]);
```

---

## 8. Exact File Paths, Props & State Blueprint

| Component / File | Role & Modifications |
|---|---|
| `/home/ewilliamhe/hatake-shop/src/pages/AdminDashboard.tsx` | Main container. Contains Leads tab rendering, button handlers, modal states, and socket listeners. |
| `/home/ewilliamhe/hatake-shop/src/components/AdminLeadsFunnel.tsx` (Recommended new component or sub-render) | Dedicated funnel visualization widget rendering the 5-stage overview cards and conversion statistics. |
| `/home/ewilliamhe/hatake-shop/src/db/schema.ts` | Backend schema. `status` enum needs `'opened'` and `'clicked'`; add `clickedAt: timestamp('clicked_at')` and `resendEmailId: text('resend_email_id')`. |
| `/home/ewilliamhe/hatake-shop/server.ts` | Backend API. Ensure `/api-v2/admin/leads/send` uses correct credentials, `/api-v2/webhooks/resend` is registered, and `io.emit` broadcasts status changes. |

---

## 9. Verification & Acceptance Checklist for Implementer

- [ ] "Send Next 50 Invites" button triggers `POST /api-v2/admin/leads/send` with `{ limit: 50 }`.
- [ ] No 500 errors on dispatch; `toast.success` reports exact number of emails sent.
- [ ] Disabled state active when sending or when pending count is 0.
- [ ] Aggregate Funnel header displays 5 stages: Pending → Sent → Opened → Clicked → Recruited with counts and conversion %.
- [ ] Table rows render color-coded badges for all statuses including `'opened'` and `'clicked'`.
- [ ] Table filter dropdown includes options for all funnel stages.
- [ ] Real-time updates via Socket.io and polling update the dashboard when webhooks fire.
