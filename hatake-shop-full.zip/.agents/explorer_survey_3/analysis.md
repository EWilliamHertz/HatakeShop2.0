# Comprehensive Resend Integration & Webhook Architecture Analysis

## 1. Executive Summary

This investigation explores the codebase at `/home/ewilliamhe/hatake-shop` to design and validate the architecture for the **Automated Vendor Outreach Engine**:
- **Manual Batch Outreach**: Dispatching personalized B2B emails to batches of 50 unrecruited TCG vendors via the Resend API with credentials `RESEND_API_KEY=re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv`, `RESEND_FROM_EMAIL=b2b@hatake.social`, and `RESEND_REPLY_TO=ernst@hatake.eu`.
- **Advanced Tracking Webhook**: Receiving and parsing Resend webhook events (`email.delivered`, `email.opened`, `email.clicked`) at `/api-v2/webhooks/resend` to update lead status in real-time.
- **Funnel Progression**: Managing monotonic vendor funnel states: `pending` (0) → `sent` (1) → `opened` (2) → `clicked` (3) → `recruited` (4).
- **Admin Leads UI**: Upgrading the Leads tab in `src/pages/AdminDashboard.tsx` to include a "Send Next 50 Invites" button, visual funnel analytics, and multi-state tracking badges.

---

## 2. Dependency & SDK Investigation

### 2.1 Package Analysis
- **`package.json` (`/home/ewilliamhe/hatake-shop/package.json`)**:
  - Line 50 explicitly lists: `"resend": "^6.25.0"`
- **Installed Version (`node_modules/resend/package.json`)**:
  - Exact version: `6.25.0`
  - Dependencies:
    - `"standardwebhooks": "1.0.0"` (Official standard webhook verification library created by Svix)
    - `"postal-mime": "2.7.5"`
- **SDK Exports (`node_modules/resend/dist/index.d.mts`)**:
  - `Resend`: Primary client class (`new Resend(apiKey)`)
  - `resend.batch.send(payload, options)`: Built-in batch dispatch method supporting up to 100 emails in a single HTTP request.
  - `resend.webhooks.verify({ payload, headers, webhookSecret })`: Built-in Svix/standard-webhook cryptographic verification.
  - `WebhookEventPayload`, `EmailOpenedEvent`, `EmailClickedEvent`, `EmailDeliveredEvent`, `EmailBouncedEvent`, etc.
- **Conclusion**: **No new dependencies are required**. The existing installation has the latest Resend SDK with built-in batch sending and webhook verification.

---

## 3. Environment & Configuration Analysis

### 3.1 Current `.env` State (`/home/ewilliamhe/hatake-shop/.env`)
- Contains Neon Postgres `DATABASE_URL`, Stripe keys (`STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `VITE_STRIPE_PUBLISHABLE_KEY`), Agora keys, and ImgBB keys.
- Currently **missing** Resend environment variables.

### 3.2 Current `server.ts` Fallbacks (`/home/ewilliamhe/hatake-shop/server.ts`)
- Line 10: `const resend = new Resend(process.env.RESEND_API_KEY || "re_Cp41ejhy_3wYC8Bm2d8LxKzu3vsWoCwYP");` (uses outdated fallback API key).
- Line 601: `from: "Hatake <hello@hatake.shop>"` (hardcoded sender, missing reply-to).
- Line 767 & 2009: `from: "Hatake <onboarding@resend.dev>"` (testing fallbacks).

### 3.3 Required Configuration
The following variables must be added to `.env` and `.env.example`:
```env
# Resend Outreach Configuration
RESEND_API_KEY=re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv
RESEND_FROM_EMAIL=b2b@hatake.social
RESEND_REPLY_TO=ernst@hatake.eu
RESEND_WEBHOOK_SECRET=whsec_... # Optional in dev; required if signature verification is strictly enforced
```

When sending emails:
- Sender format: `"Hatake B2B <" + (process.env.RESEND_FROM_EMAIL || "b2b@hatake.social") + ">"`
- Reply-To format: `process.env.RESEND_REPLY_TO || "ernst@hatake.eu"`

---

## 4. Email Branding, Templates & Invite Link Architecture

### 4.1 Existing Email Template (`src/lib/emailTemplate.ts`)
The project already features an email template function:
`generateB2BEmailHtml(companyNameStr, registrationUrl, unsubscribeUrl, segment = 'TCG')`

**Key Features of the Template**:
- **Hatake Branding**: Displays `${appUrl}/logo.png` centered at top.
- **Personalized Salutation**: Derives `firstName` via `companyNameStr.split(' ')[0] || "Partner"`.
- **Segment Customization**:
  - `TCG`: "trading card games", acronym "TCG", "trading card game professionals".
  - `Sports`: "sports cards and memorabilia", acronym "Sports Cards".
  - `General`: "trading cards and collectibles", acronym "Collectibles".
- **Call-to-Action**: Prominent `#4f46e5` button linking directly to `${registrationUrl}` ("Activate your B2B account").
- **Wholesale Value Propositions**:
  - Buy wholesale (sealed product, singles, accessories from verified global sellers).
  - Sell wholesale (global B2B buyer network).
  - Trade with confidence (vetted partners, escrow/Stripe protection).
  - Ship globally (integrated logistics).
- **Compliance**: Clear unsubscribe link `${unsubscribeUrl}` in the footer.

### 4.2 Invite Link & Redemption Life Cycle
1. **Token Generation (`server.ts` lines 592-595)**:
   ```typescript
   const rawToken = crypto.randomUUID();
   const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
   const appUrl = process.env.APP_URL || 'https://hatake.shop';
   const registrationUrl = `${appUrl}/login?invite=${rawToken}`;
   const unsubscribeUrl = `${appUrl}/api/unsubscribe?email=${encodeURIComponent(lead.email)}`;
   ```
2. **Database Storage**:
   The SHA-256 hash `tokenHash` is saved into `leads.inviteTokenHash`.
3. **Invitation Validation (`server.ts` line 1245)**:
   `/api-v2/invitations/validate?token=${rawToken}` hashes the token and checks if the lead exists and is unredeemed.
4. **Account Sync & Conversion (`server.ts` line 1215)**:
   When the vendor registers or logs in (`/api-v2/auth/sync`), the frontend sends `{ inviteToken: rawToken }`.
   The backend hashes the token, finds the matching lead, and updates:
   ```typescript
   await db.update(leads).set({
     status: 'recruited',
     redeemedAt: new Date()
   }).where(eq(leads.id, lead[0].id));
   ```
   It also links the lead's company name into the new user profile (`users.companyName = lead.companyName`).

---

## 5. Resend API & Webhook Specifications

### 5.1 Batch Dispatch API vs. Sequential Sending Loop
`server.ts` currently uses a sequential `for` loop calling `resend.emails.send` one by one:
```typescript
// Current slow sequential loop:
for (const lead of pendingLeads) {
   await resend.emails.send({ ... });
}
```

**Comparison with `resend.batch.send`**:
| Dimension | Sequential Loop (`resend.emails.send`) | Resend Batch API (`resend.batch.send`) |
|---|---|---|
| **Network Requests** | 50 separate HTTP requests | 1 single HTTP request |
| **Execution Time** | ~15–30 seconds | ~300–800 milliseconds |
| **Rate Limit Risk** | High (triggers 429 Too Many Requests on Resend standard tiers) | None (counts as a single API request) |
| **Timeout Risk** | High under Cloud Run / Cloud Shell proxy timeouts | Negligible |
| **SDK Support** | Supported | Supported out-of-the-box (`resend.batch.send(emails)`) |
| **Max Capacity** | N/A | Up to 100 emails per batch |

**Recommended Batch Implementation Pattern**:
```typescript
const batchPayload = pendingLeads.map((lead) => {
  const rawToken = crypto.randomUUID();
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const appUrl = process.env.APP_URL || 'https://hatake.shop';
  const registrationUrl = `${appUrl}/login?invite=${rawToken}`;
  const unsubscribeUrl = `${appUrl}/api/unsubscribe?email=${encodeURIComponent(lead.email)}`;
  const htmlContent = generateB2BEmailHtml(lead.companyName || "Partner", registrationUrl, unsubscribeUrl, lead.segment || "TCG");

  return {
    from: `Hatake B2B <${process.env.RESEND_FROM_EMAIL || 'b2b@hatake.social'}>`,
    replyTo: process.env.RESEND_REPLY_TO || 'ernst@hatake.eu',
    to: lead.email,
    subject: `${lead.companyName || 'Partner'}, join Hatake.Shop B2B`,
    html: htmlContent,
    tags: [
      { name: 'lead_id', value: String(lead.id) },
      { name: 'segment', value: lead.segment || 'TCG' }
    ],
    // Retain internal metadata for updating database after dispatch
    _meta: { leadId: lead.id, tokenHash }
  };
});

// Strip _meta for Resend SDK call
const sendData = batchPayload.map(({ _meta, ...email }) => email);
const { data, error } = await resend.batch.send(sendData);

if (error) throw new Error(error.message);

// Update database with status 'sent', sentAt, tokenHash, and resendEmailId
for (let i = 0; i < batchPayload.length; i++) {
  const meta = batchPayload[i]._meta;
  const resendId = data?.data?.[i]?.id;
  await db.update(leads).set({
    status: 'sent',
    sentAt: new Date(),
    inviteTokenHash: meta.tokenHash,
    resendEmailId: resendId || null
  }).where(eq(leads.id, meta.leadId));
}
```

---

### 5.2 Resend Webhook Event Payload Structure
Resend webhook events deliver JSON payloads with event types and message data:

#### Event Types
- `email.delivered`: The email was delivered to the recipient's mail server.
- `email.opened`: The recipient opened the email (tracked via invisible tracking pixel).
- `email.clicked`: The recipient clicked a tracked link inside the email.
- `email.bounced`: The email was rejected by the recipient mail server.
- `email.complained`: Recipient marked email as spam.

#### Payload Schema (TypeScript definitions from `node_modules/resend/dist/index.d.mts` lines 2346-2472)
```typescript
interface WebhookEventPayload {
  type: 'email.delivered' | 'email.opened' | 'email.clicked' | 'email.bounced' | ...;
  created_at: string; // ISO 8601, e.g. "2026-09-09T16:00:00.000Z"
  data: {
    email_id: string;   // Unique Resend email UUID
    created_at: string;
    from: string;       // e.g. "b2b@hatake.social"
    to: string[];       // e.g. ["vendor@cards.com"]
    subject: string;
    tags?: Record<string, string>; // e.g. { lead_id: "42", segment: "TCG" }
    click?: {
      ipAddress: string;
      link: string;     // Clicked URL (e.g. registration URL)
      timestamp: string;
      userAgent: string;
    };
    bounce?: {
      message: string;
      subType: string;
      type: string;
    };
  };
}
```

#### Signature Verification Headers
Resend uses the **Standard Webhooks** specification (created by Svix). Headers sent:
- `svix-id` (or `webhook-id`): Unique event attempt ID.
- `svix-timestamp` (or `webhook-timestamp`): Unix timestamp in seconds.
- `svix-signature` (or `webhook-signature`): HMAC-SHA256 signature in format `v1,<base64>`.

---

### 5.3 3-Tier Lead Identification Strategy
When a webhook arrives, how do we link it back to a specific lead in the database?
We implement a 3-tier lookup:

```
                  ┌───────────────────────────────┐
                  │ Webhook Payload Arrives       │
                  └──────────────┬────────────────┘
                                 │
                 Tier 1: data.tags.lead_id exists?
                     ┌───────────┴───────────┐
                    YES                      NO
                     │                       │
           SELECT by leads.id                │
                     │         Tier 2: data.email_id exists?
                  Found?         ┌───────────┴───────────┐
                 YES   NO       YES                      NO
                  │     └────────┼────────┐               │
                  │              │        │               │
                  │    SELECT by leads.   │               │
                  │    resendEmailId      │               │
                  │              │        │               │
                  │           Found?      │               │
                  │          YES   NO     │               │
                  │           │     └─────┴───────┐       │
                  │           │                   │       │
                  │           │   Tier 3: SELECT by leads.email
                  │           │   (data.to[0])    │       │
                  │           │          ┌────────┴───────┘
                  │           │        Found?
                  │           │       YES   NO
                  ▼           ▼        ▼     ▼
                [ Update Matching Lead ]   [ Log Warning & Ignore ]
```

1. **Tier 1 (Custom Tag)**: `data.tags?.lead_id`. Resend echoes back the tags set at send time. This is fastest and completely disambiguated.
2. **Tier 2 (Resend Email ID)**: `data.email_id`. Matches the `resendEmailId` column stored during batch dispatch.
3. **Tier 3 (Recipient Email)**: `data.to[0]`. In `src/db/schema.ts`, `leads.email` has a `unique()` constraint, providing a foolproof fallback.

---

### 5.4 Funnel Progression & Monotonic State Transitions
Vendors move strictly forward through the funnel:

```
[ Pending ] (0)
     │
     ▼ (Admin triggers "Send Next 50 Invites")
  [ Sent ] (1)
     │
     ▼ (Resend Webhook: 'email.opened')
 [ Opened ] (2)
     │
     ▼ (Resend Webhook: 'email.clicked')
 [ Clicked ] (3)
     │
     ▼ (Vendor registers / logs in via invite token)
[ Recruited ] (4)
```

**State Transition Rules**:
- A webhook event `email.opened` updates `status` to `'opened'` **only if** current status is `'pending'` or `'sent'`. It updates `openedAt = now()`.
- A webhook event `email.clicked` updates `status` to `'clicked'` **only if** current status is not `'recruited'`. It updates `clickedAt = now()` and backfills `openedAt` if missing.
- If a lead has already reached `'recruited'`, subsequent `email.opened` or `email.clicked` events record timestamps but **do not** downgrade the status.
- Real-time notification: After updating the database, `server.ts` emits `io.emit("lead_updated", { id: lead.id, status, openedAt, clickedAt })` to instantly update all active admin browser sessions via WebSockets.

---

### 5.5 Express Webhook Endpoint Architecture
In `server.ts`:
- **Placement**: Like `/api-v2/stripe/webhook` (lines 291-322), the Resend webhook endpoint `/api-v2/webhooks/resend` **must** be mounted with `express.raw({ type: 'application/json' })` **before** `app.use(express.json())`.
- **Reason**: Standard Webhooks / Svix signature verification requires the exact, unmutated raw byte buffer.
- **Dual Verification Mode (Production Security + Dev Testability)**:
  - If `RESEND_WEBHOOK_SECRET` is configured AND signature headers (`svix-id`, `svix-timestamp`, `svix-signature`) are present: Verify signature via `resend.webhooks.verify(...)`.
  - If `RESEND_WEBHOOK_SECRET` is not set OR signature headers are absent (e.g. when testing with `curl` or automated test scripts in development): Parse `rawBody.toString('utf8')` as JSON directly.

---

## 6. Database Schema Enhancements

In `src/db/schema.ts` (lines 204-221):
```typescript
export const leads = pgTable('leads', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  companyName: text('company_name'),
  location: text('location'),
  segment: text('segment').default('TCG'),
  // Expanded enum to support opened and clicked tracking states:
  status: text('status', { enum: ['pending', 'sent', 'opened', 'clicked', 'recruited', 'failed'] }).default('pending'),
  website: text('website'),
  socialLinks: jsonb('social_links').default(sql`'[]'::jsonb`),
  inviteTokenHash: text('invite_token_hash'),
  resendEmailId: text('resend_email_id'), // NEW: Track Resend message ID
  openedAt: timestamp('opened_at'),
  clickedAt: timestamp('clicked_at'),     // NEW: Track click timestamp
  dripStep: integer('drip_step').default(1),
  lastEmailedAt: timestamp('last_emailed_at'),
  referredById: integer('referred_by_id'),
  redeemedAt: timestamp('redeemed_at'),
  sentAt: timestamp('sent_at'),
  createdAt: timestamp('created_at').defaultNow(),
});
```
*Note*: In Postgres, `status` is already a native `text` column (`"status" text DEFAULT 'pending'`), so updating the Drizzle schema allows TypeScript to validate `'opened'` and `'clicked'`. If adding `clicked_at` and `resend_email_id`, a simple `ALTER TABLE leads ADD COLUMN IF NOT EXISTS clicked_at timestamp; ALTER TABLE leads ADD COLUMN IF NOT EXISTS resend_email_id text;` can be executed.

---

## 7. Admin Leads UI Upgrades (`src/pages/AdminDashboard.tsx`)

### 7.1 Funnel Analytics Header
Upgrade lines 838-850 to render a full visual 5-stage funnel card:
- **Metrics Bar**:
  - `Total Leads`: Total count
  - `Pending`: Count waiting to be dispatched
  - `Sent`: Dispatched count
  - `Opened`: Count and Open Rate (`opened / sent %`)
  - `Clicked`: Count and Click-Through Rate (`clicked / sent %`)
  - `Recruited`: Count and Overall Conversion Rate (`recruited / total %`)

### 7.2 Action Button
- In line 923, update button text to `"Send Next 50 Invites"`.
- Button triggers `POST /api-v2/admin/leads/send` with `{ limit: 50 }`.
- Disables with spinner when sending.

### 7.3 Status Filter Dropdown
Update filter dropdown (lines 939-945) to include:
- `All Status`
- `To-Send (Pending)`
- `Sent`
- `Opened`
- `Clicked`
- `Recruited`

### 7.4 Table Badges & Timestamps
Update lines 974-976 to render styled status pills:
- `PENDING`: Gray badge
- `SENT`: Blue badge with `sentAt` timestamp
- `OPENED`: Amber/Yellow badge with `openedAt` timestamp
- `CLICKED`: Purple/Indigo badge with `clickedAt` timestamp
- `RECRUITED`: Emerald/Green badge with `redeemedAt` timestamp

### 7.5 Real-Time WebSocket Listener
Add `socket.io-client` listener in `AdminDashboard.tsx`:
```typescript
useEffect(() => {
  const socket = io();
  socket.on("lead_updated", (updatedLead: any) => {
    setLeads((prev: any[]) => prev.map((l) => (l.id === updatedLead.id ? { ...l, ...updatedLead } : l)));
  });
  return () => {
    socket.disconnect();
  };
}, []);
```

---

## 8. Testability & Simulation Specifications

### 8.1 Testing with `curl` (No Signatures Needed in Dev Mode)

#### Simulate `email.delivered`:
```bash
curl -X POST http://localhost:5000/api-v2/webhooks/resend \
  -H "Content-Type: application/json" \
  -d '{
    "type": "email.delivered",
    "created_at": "2026-09-09T16:00:00.000Z",
    "data": {
      "email_id": "49a3999c-0ce1-4ea6-ab68-afcd6dc2e794",
      "from": "b2b@hatake.social",
      "to": ["vendor@tcgshop.com"],
      "subject": "TCG Shop, join Hatake.Shop B2B",
      "tags": {
        "lead_id": "1"
      }
    }
  }'
```

#### Simulate `email.opened`:
```bash
curl -X POST http://localhost:5000/api-v2/webhooks/resend \
  -H "Content-Type: application/json" \
  -d '{
    "type": "email.opened",
    "created_at": "2026-09-09T16:02:00.000Z",
    "data": {
      "email_id": "49a3999c-0ce1-4ea6-ab68-afcd6dc2e794",
      "from": "b2b@hatake.social",
      "to": ["vendor@tcgshop.com"],
      "subject": "TCG Shop, join Hatake.Shop B2B",
      "tags": {
        "lead_id": "1"
      }
    }
  }'
```

#### Simulate `email.clicked`:
```bash
curl -X POST http://localhost:5000/api-v2/webhooks/resend \
  -H "Content-Type: application/json" \
  -d '{
    "type": "email.clicked",
    "created_at": "2026-09-09T16:05:00.000Z",
    "data": {
      "email_id": "49a3999c-0ce1-4ea6-ab68-afcd6dc2e794",
      "from": "b2b@hatake.social",
      "to": ["vendor@tcgshop.com"],
      "subject": "TCG Shop, join Hatake.Shop B2B",
      "tags": {
        "lead_id": "1"
      },
      "click": {
        "ipAddress": "127.0.0.1",
        "link": "https://hatake.shop/login?invite=mock-token",
        "timestamp": "2026-09-09T16:05:00.000Z",
        "userAgent": "Mozilla/5.0"
      }
    }
  }'
```

### 8.2 Testing Cryptographic Signatures (Svix Standard Webhooks)
When `RESEND_WEBHOOK_SECRET` is set, test scripts can generate genuine Svix headers:
```typescript
import { Webhook } from 'standardwebhooks';

const secret = 'whsec_testsecret1234567890abcdef';
const wh = new Webhook(secret);

const payload = JSON.stringify({
  type: 'email.opened',
  created_at: new Date().toISOString(),
  data: {
    email_id: 'test-email-id',
    from: 'b2b@hatake.social',
    to: ['test@tcg.com'],
    tags: { lead_id: '1' }
  }
});

const msgId = 'msg_' + Date.now();
const timestamp = new Date();
const signature = wh.sign(msgId, timestamp, payload);

const response = await fetch('http://localhost:5000/api-v2/webhooks/resend', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'svix-id': msgId,
    'svix-timestamp': String(Math.floor(timestamp.getTime() / 1000)),
    'svix-signature': signature,
  },
  body: payload
});
```

---

## 9. Next Steps for Implementation Agent
1. **Environment Setup**:
   - Add `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `RESEND_REPLY_TO` to `.env`.
2. **Database Schema Update**:
   - Update `src/db/schema.ts` `leads.status` enum and add `clickedAt`, `resendEmailId`.
   - Run migration query if needed: `ALTER TABLE leads ADD COLUMN IF NOT EXISTS clicked_at timestamp; ALTER TABLE leads ADD COLUMN IF NOT EXISTS resend_email_id text;`.
3. **Backend Route Implementations (`server.ts`)**:
   - Upgrade `/api-v2/admin/leads/send` to use `resend.batch.send` with credentials and tags.
   - Mount `/api-v2/webhooks/resend` with `express.raw({ type: 'application/json' })` before `app.use(express.json())`.
   - Implement the 3-tier lead lookup, monotonic state update, and Socket.IO broadcast.
4. **Frontend UI Enhancements (`src/pages/AdminDashboard.tsx`)**:
   - Add "Send Next 50 Invites" button.
   - Add Funnel metrics card and status filters.
   - Add status badges for `opened` and `clicked`.
   - Add Socket.IO listener for real-time updates.
5. **Verification**:
   - Execute curl test payloads.
   - Verify lead status updates in Postgres.
   - Check UI rendering.
