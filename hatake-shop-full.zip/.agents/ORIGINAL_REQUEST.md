# Original User Request

## Initial Request — 2026-09-09T16:40:05Z

# Teamwork Project Prompt — Draft

Build an Automated Vendor Outreach Engine that allows admins to manually dispatch personalized, branded emails to batches of 50 TCG vendors containing unique Hatake invite links, using the Resend API. Additionally, implement an advanced tracking system using webhooks to capture and display "Opened" and "Clicked" statuses in real-time.

Working directory: /home/ewilliamhe/hatake-shop
Integrity mode: development

## Requirements

### R1. Resend Integration & Manual Dispatch
Implement email sending logic using the Resend SDK with the provided credentials (`RESEND_API_KEY=re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv`, `RESEND_FROM_EMAIL=b2b@hatake.social`, `RESEND_REPLY_TO=ernst@hatake.eu`). Add a "Send Next 50 Invites" button to the Admin Leads UI that triggers a batch email to unrecruited vendors.

### R2. Advanced Tracking via Webhooks
Expose a dedicated webhook endpoint in `server.ts` (e.g., `/api-v2/webhooks/resend`) to securely receive event payloads from Resend (delivered, opened, clicked). Update the `leads` table in the database to reflect these advanced tracking states.

### R3. Tracking Dashboard UI
Enhance the existing Admin "Leads" UI to visually display the full funnel of tracking states for each vendor: Pending → Sent → Opened → Clicked → Recruited.

## Acceptance Criteria

### Functionality & Integration
- [ ] The Resend SDK is properly integrated, and the "Send 50 Invites" button in the frontend successfully triggers the backend dispatch logic without throwing a 500 error.
- [ ] The backend webhook endpoint correctly parses a simulated Resend JSON payload (e.g., via `curl`) and successfully updates a mock Lead's status to 'opened' or 'clicked' in the Postgres database.
- [ ] The frontend UI accurately retrieves and renders these new advanced statuses ('opened', 'clicked') seamlessly.
