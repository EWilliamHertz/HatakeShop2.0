# Backend Architecture, Database Setup & Lead Outreach Investigation Report

**Author**: `explorer_survey_1` (Backend & Database Explorer)  
**Date**: 2026-09-09  
**Repository**: `/home/ewilliamhe/hatake-shop`  
**Status**: Investigation Complete

---

## Executive Summary

This report maps the backend architecture, database configuration, lead management schemas, existing outreach workflows, and integration requirements for the Hatake Shop B2B vendor outreach system. The codebase is a TypeScript full-stack application built on **Express 4.21.2**, **Drizzle ORM 0.45.2**, **PostgreSQL (Neon Serverless)**, **Socket.IO 4.8.3**, and **Resend SDK 6.25.0**.

Existing outreach mechanisms already have a functional foundation in `/api-v2/admin/leads/send` and `/api-v2/admin/leads/upload`, but require critical updates to:
1. Support the new funnel tracking states (`opened`, `clicked`) in schema and database.
2. Incorporate provided Resend credentials (`RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `RESEND_REPLY_TO`).
3. Add a dedicated public webhook endpoint `/api-v2/webhooks/resend` to capture Resend webhook events (delivered, opened, clicked) and broadcast real-time updates via Socket.IO.
4. Prevent state regression (e.g. not downgrading `recruited` or `clicked` leads).
5. Ensure metrics (`sentCount`) correctly count all dispatched leads across the funnel.

---

## 1. Backend Architecture & Entry Points

### 1.1 Server Framework & Execution
- **Entry point**: `/home/ewilliamhe/hatake-shop/server.ts` (2,915 lines)
- **Framework**: Express (`express@^4.21.2`) wrapped in Node `http.createServer(app)`.
- **Real-Time Communication**: `socket.io` (`Server@^4.8.3`) mounted on `httpServer` with CORS origin `*` (`server.ts:118-120`).
- **Development Runtime**: `npm run dev` executes `tsx server.ts` (`package.json:7`).
- **Production Build**: `npm run build` runs `vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs` (`package.json:8`).
- **Production Runtime**: `npm start` executes `node dist/server.cjs` (`package.json:9`).
- **Port**: Default 3000 (`server.ts:218`), bound to `0.0.0.0:3000` (`server.ts:2904`).
- **Frontend Serving**: In development, Vite server runs in middleware mode via `app.use(vite.middlewares)` (`server.ts:2890-2895`). In production, static assets are served from `dist/` with an SPA fallback (`server.ts:2896-2902`).

### 1.2 Middleware Order & Body Parsers
The middleware order in `server.ts` is crucial:
1. **Socket.IO Injection**:
   - `server.ts:220-223`:
     ```ts
     app.use((req, res, next) => {
       (req as any).io = io;
       next();
     });
     ```
2. **Raw Body Webhook (Stripe)**:
   - `server.ts:291`:
     ```ts
     app.post("/api-v2/stripe/webhook", express.raw({ type: 'application/json' }), async (req, res) => ...);
     ```
     Mounted *before* global body parsers to preserve the raw buffer for cryptographic signature validation.
3. **Global Body Parsers**:
   - `server.ts:324-325`:
     ```ts
     app.use(express.json({ limit: '50mb' }));
     app.use(express.urlencoded({ limit: '50mb', extended: true }));
     ```
4. **Authentication & Authorization**:
   - `src/middleware/auth.ts`: Defines `requireAuth` (verifies Bearer token via Firebase Admin SDK `adminAuth.verifyIdToken`, or custom tokens `custom-token-<uid>`, or `mock-admin-token`).
   - `server.ts:345-354`: Defines `requireAdmin` (checks `userProfile.role === 'admin'`).
   - `server.ts:356-367`: Defines `requireSeller` (checks `['seller', 'both', 'admin']`).

### 1.3 Routing Layout
All REST API endpoints are organized under the `/api-v2/` prefix directly within `server.ts`. No Express Routers in sub-files are used; all routes are declared inline.
Key lead routes include:
- `GET /api-v2/admin/leads` (`server.ts:484`): Fetches all leads and `sentCount`.
- `POST /api-v2/admin/leads/upload` (`server.ts:497`): CSV batch import of leads.
- `GET /api-v2/admin/leads/preview` (`server.ts:572`): Returns HTML preview of outreach email.
- `POST /api-v2/admin/leads/send` (`server.ts:584`): Dispatches emails to pending leads.
- `GET /api-v2/leads` (`server.ts:625`): Public lead list.
- `PATCH /api-v2/leads/:id` (`server.ts:634`): Updates status of a lead.
- `GET /api-v2/leads/progress` (`server.ts:647`): Returns outreach campaign counter (`sentCount` / 20,000).
- `POST /api-v2/auth/sync` (`server.ts:1215`): Redeems invite token, marks lead as `recruited`.
- `GET /api-v2/invitations/validate` (`server.ts:1245`): Validates token hash for invite links.
- `GET /api-v2/public/partners` (`server.ts:2814`): Returns non-pending leads and sellers for directory.

---

## 2. Database Configuration & ORM Mechanics

### 2.1 Connection Setup
- **ORM / Client**: `drizzle-orm@^0.45.2` with `pg@^8.23.0` (`node-postgres`).
- **Connection File**: `/home/ewilliamhe/hatake-shop/src/db/index.ts` (lines 1–38).
- **Pool Management**:
  ```ts
  export const createPool = () => {
    if (!global._postgresPool) {
      const config: pg.PoolConfig = {
        max: 10,
        connectionTimeoutMillis: 30000,
      };
      if (process.env.DATABASE_URL) {
        config.connectionString = process.env.DATABASE_URL;
      } else {
        config.host = process.env.SQL_HOST;
        config.user = process.env.SQL_USER;
        config.password = process.env.SQL_PASSWORD;
        config.database = process.env.SQL_DB_NAME;
      }
      global._postgresPool = new Pool(config);
    }
    return global._postgresPool;
  };
  export const db = drizzle(pool, { schema });
  ```
- **Live Database**: Neon Serverless PostgreSQL (`ep-calm-field-aeat24a7-pooler.c-2.us-east-2.aws.neon.tech`), configured via `DATABASE_URL` in `.env`.

### 2.2 Drizzle Configuration & Migration Mechanics
- **Config File**: `/home/ewilliamhe/hatake-shop/src/db/drizzle.config.ts`.
  - Dialect: `postgresql`
  - Schema: `./src/db/schema.ts`
  - Database credentials from `process.env.DATABASE_URL`.
- **Migration History**:
  - Located in `/home/ewilliamhe/hatake-shop/drizzle/`:
    - `0000_tricky_owl.sql`: Core tables (`users`, `categories`, `products`, `inquiries`, `inquiry_messages`).
    - `0001_majestic_carlie_cooper.sql`: Creates `leads`, `affiliates`, `marketing_logs`.
    - `0002_steep_tony_stark.sql`: Adds `website`, `social_links` to `leads`.
    - `0003_hard_black_queen.sql`: Adds `invite_token_hash`, `opened_at`, `redeemed_at` to `leads`.
    - `0004_colorful_gabe_jones.sql`: Modifies `inquiries.status`.
    - `0005_medical_steel_serpent.sql`: Adds `reviews` table and `inquiries.invoice_url`.
  - Incremental column additions were also performed via `add_columns_dev.cjs` / `add_columns_prod.cjs` (`drip_step`, `last_emailed_at`, `referred_by_id`).
- **Postgres Column Data Type**: The column `status` in the Postgres `leads` table is defined as PostgreSQL type `text DEFAULT 'pending'`, NOT a native Postgres enum. In Drizzle ORM TypeScript, it is constrained via `{ enum: ['pending', 'sent', 'recruited', 'failed'] }`.

---

## 3. Detailed Schema Analysis: `leads` Table

### 3.1 Drizzle Schema Definition
Location: `/home/ewilliamhe/hatake-shop/src/db/schema.ts` (lines 204–221):
```ts
export const leads = pgTable('leads', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  companyName: text('company_name'),
  location: text('location'),
  segment: text('segment').default('TCG'),
  status: text('status', { enum: ['pending', 'sent', 'recruited', 'failed'] }).default('pending'),
  website: text('website'),
  socialLinks: jsonb('social_links').default(sql`'[]'::jsonb`),
  inviteTokenHash: text('invite_token_hash'),
  openedAt: timestamp('opened_at'),
  dripStep: integer('drip_step').default(1),
  lastEmailedAt: timestamp('last_emailed_at'),
  referredById: integer('referred_by_id'),
  redeemedAt: timestamp('redeemed_at'),
  sentAt: timestamp('sent_at'),
  createdAt: timestamp('created_at').defaultNow(),
});
```

### 3.2 Column Breakdown

| Column Name | DB Column Name | TypeScript Type | DB Type | Nullable | Default | Description |
|---|---|---|---|---|---|---|
| `id` | `id` | `number` | `serial` | No | Auto (PK) | Primary key |
| `email` | `email` | `string` | `text` | No | None | Unique vendor contact email |
| `companyName` | `company_name` | `string \| null` | `text` | Yes | `null` | Vendor business name |
| `location` | `location` | `string \| null` | `text` | Yes | `null` | City/State/Country |
| `segment` | `segment` | `string \| null` | `text` | Yes | `'TCG'` | Market segment (`TCG`, `Sports`, `General`) |
| `status` | `status` | `string` | `text` | Yes | `'pending'` | Funnel state (see Section 3.3) |
| `website` | `website` | `string \| null` | `text` | Yes | `null` | Website URL |
| `socialLinks` | `social_links` | `unknown` | `jsonb` | Yes | `'[]'::jsonb` | Array of social profile URLs |
| `inviteTokenHash` | `invite_token_hash` | `string \| null` | `text` | Yes | `null` | SHA-256 hash of unique invite token |
| `openedAt` | `opened_at` | `Date \| null` | `timestamp` | Yes | `null` | Timestamp when recipient opened email |
| `dripStep` | `drip_step` | `number \| null` | `integer` | Yes | `1` | Drip step for follow-up emails |
| `lastEmailedAt` | `last_emailed_at` | `Date \| null` | `timestamp` | Yes | `null` | Timestamp of most recent email dispatch |
| `referredById` | `referred_by_id` | `number \| null` | `integer` | Yes | `null` | Foreign user ID if referred |
| `redeemedAt` | `redeemed_at` | `Date \| null` | `timestamp` | Yes | `null` | Timestamp when invite was redeemed |
| `sentAt` | `sent_at` | `Date \| null` | `timestamp` | Yes | `null` | Timestamp when initial invite was sent |
| `createdAt` | `created_at` | `Date \| null` | `timestamp` | Yes | `now()` | Record creation timestamp |

### 3.3 Funnel Status Evolution
- **Current Enums in Schema**: `'pending' | 'sent' | 'recruited' | 'failed'`
- **Target Funnel Enums**:
  ```ts
  enum: ['pending', 'sent', 'delivered', 'opened', 'clicked', 'recruited', 'failed']
  ```
  The complete funnel:
  $$\text{Pending} \longrightarrow \text{Sent (or Delivered)} \longrightarrow \text{Opened} \longrightarrow \text{Clicked} \longrightarrow \text{Recruited}$$
- **Recommended Additional Columns**:
  - `clickedAt`: `timestamp('clicked_at')` — To record the exact time the invitation link was clicked.
  - `resendEmailId`: `text('resend_email_id')` — To record the Resend email ID (`res.data.id`) returned upon sending.

### 3.4 Constraints & Indexes
- **Existing Constraints**:
  - Primary Key: `leads_pkey` on `id`
  - Unique: `leads_email_unique` on `email`
- **Missing Recommended Indexes**:
  - `leads_status_idx` on `status` (for rapid querying of pending batches and funnel metrics).
  - `leads_invite_token_hash_idx` on `invite_token_hash` (for fast registration validation).
  - `leads_resend_email_id_idx` on `resend_email_id` (for immediate O(1) webhook lookup).

---

## 4. Existing Lead Querying & Outreach Logic

### 4.1 Dispatching Route: `/api-v2/admin/leads/send`
Located in `server.ts:584–623`:
```ts
app.post("/api-v2/admin/leads/send", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { limit = 100 } = req.body;
    const pendingLeads = await db.select().from(leads).where(eq(leads.status, 'pending')).limit(limit);
    let sent = 0;
    for (const lead of pendingLeads) {
      try {
        const rawToken = crypto.randomUUID();
        const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
        const appUrl = process.env.APP_URL || 'https://hatake.shop';
        const registrationUrl = `${appUrl}/login?invite=${rawToken}`;
        const unsubscribeUrl = `${appUrl}/api/unsubscribe?email=${encodeURIComponent(lead.email)}`;
        
        const htmlContent = generateB2BEmailHtml(lead.companyName || "Partner", registrationUrl, unsubscribeUrl, lead.segment || "TCG");
        
        await resend.emails.send({
          from: "Hatake <hello@hatake.shop>",
          to: lead.email,
          subject: `${lead.companyName || 'Partner'}, join Hatake.Shop B2B`,
          html: htmlContent
        });
        
        await db.update(leads).set({ 
           status: 'sent', 
           sentAt: new Date(),
          inviteTokenHash: tokenHash
        }).where(eq(leads.id, lead.id));
        sent++;
      } catch (e) {
        console.error("Error sending to " + lead.email, e);
        await db.update(leads).set({ status: 'failed' }).where(eq(leads.id, lead.id));
      }
    }
    res.json({ success: true, sent });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
```

### 4.2 Lead Recruitment Mechanics
Located in `server.ts:1215–1243` (`/api-v2/auth/sync`):
```ts
if (inviteToken) {
   const tokenHash = crypto.createHash('sha256').update(inviteToken).digest('hex');
   const lead = await db.select().from(leads).where(eq(leads.inviteTokenHash, tokenHash)).limit(1);
   if (lead.length > 0 && lead[0].status !== 'recruited') {
      finalCompanyName = lead[0].companyName || "";
      await db.update(leads).set({ status: 'recruited', redeemedAt: new Date() }).where(eq(leads.id, lead[0].id));
   }
}
```
In addition, `PATCH /api-v2/leads/:id` allows admins to manually toggle status to `'recruited'` or `'pending'`.

### 4.3 Campaign Metric Queries
In `server.ts:487` and `server.ts:649`:
```ts
const sentCount = await db.select({ count: sql`count(*)` }).from(leads).where(eq(leads.status, 'sent'));
```
**Important Bug Warning**: Notice that `sentCount` is currently calculated strictly where `leads.status = 'sent'`. When leads transition to `'opened'`, `'clicked'`, or `'recruited'`, this count will decrement unless the query is updated to count all contacted leads:
```ts
where(not(eq(leads.status, 'pending')))
// or
where(inArray(leads.status, ['sent', 'delivered', 'opened', 'clicked', 'recruited']))
```

---

## 5. Recommended Backend Architecture

### 5.1 Requirement R1: Batch Dispatching 50 Unrecruited Vendors

#### 5.1.1 Configuration & Environment Variables
Add the provided credentials to `.env` and `server.ts`:
```env
RESEND_API_KEY="re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv"
RESEND_FROM_EMAIL="b2b@hatake.social"
RESEND_REPLY_TO="ernst@hatake.eu"
```

In `server.ts`:
```ts
const resendApiKey = process.env.RESEND_API_KEY || "re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv";
const resendFromEmail = process.env.RESEND_FROM_EMAIL || "b2b@hatake.social";
const resendReplyTo = process.env.RESEND_REPLY_TO || "ernst@hatake.eu";
const resend = new Resend(resendApiKey);
```

#### 5.1.2 Dispatch Query & Execution Logic
In `/api-v2/admin/leads/send`:
1. **Query**: Select up to 50 pending leads ordered deterministically:
   ```ts
   const targetLeads = await db.select()
     .from(leads)
     .where(or(eq(leads.status, 'pending'), sql`${leads.status} IS NULL`))
     .orderBy(asc(leads.id))
     .limit(limit);
   ```
2. **Email Construction & Delivery**:
   ```ts
   const rawToken = crypto.randomUUID();
   const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
   const appUrl = process.env.APP_URL || 'https://hatake.shop';
   const registrationUrl = `${appUrl}/login?invite=${rawToken}`;
   const unsubscribeUrl = `${appUrl}/api/unsubscribe?email=${encodeURIComponent(lead.email)}`;

   const htmlContent = generateB2BEmailHtml(
     lead.companyName || "Partner",
     registrationUrl,
     unsubscribeUrl,
     lead.segment || "TCG"
   );

   const resendResult = await resend.emails.send({
     from: `Hatake B2B <${resendFromEmail}>`,
     to: lead.email,
     replyTo: resendReplyTo,
     subject: `${lead.companyName || 'Partner'}, join Hatake.Shop B2B`,
     html: htmlContent,
     headers: {
       'X-Entity-Ref-ID': rawToken,
     }
   });
   ```
3. **Database Update**:
   ```ts
   const resendEmailId = resendResult?.data?.id || null;
   await db.update(leads).set({
     status: 'sent',
     sentAt: new Date(),
     lastEmailedAt: new Date(),
     inviteTokenHash: tokenHash,
     resendEmailId: resendEmailId,
   }).where(eq(leads.id, lead.id));
   ```
4. **Resilience**: Wrap each lead dispatch in individual `try/catch`. If an individual email fails, set `status: 'failed'` and continue dispatching the remaining batch.

---

### 5.2 Requirement R2: Dedicated Webhook Endpoint (`/api-v2/webhooks/resend`)

#### 5.2.1 Route Definition & Middleware
- **Endpoint**: `POST /api-v2/webhooks/resend`
- **Authentication**: Public (no `requireAuth` / `requireAdmin`). Webhooks originate from Resend's servers or automated test scripts (e.g. `curl`).
- **Body Parsing**: Placed after `app.use(express.json({ limit: '50mb' }))` so `req.body` is automatically parsed for JSON requests. In addition, include buffer/string decoding fallback for compatibility with raw HTTP posts:
  ```ts
  let payload = req.body;
  if (Buffer.isBuffer(payload)) {
    try { payload = JSON.parse(payload.toString('utf8')); } catch(e) {}
  } else if (typeof payload === 'string') {
    try { payload = JSON.parse(payload); } catch(e) {}
  }
  ```
- **Webhook Signature Security**:
  If `process.env.RESEND_WEBHOOK_SECRET` is set and Svix headers (`svix-id`, `svix-timestamp`, `svix-signature`) are present:
  Optional verification can be performed. If headers are absent (e.g. simulated `curl` testing), the endpoint processes the event directly, fulfilling Acceptance Criterion 2.

#### 5.2.2 Event Extraction & Recipient Identification
Resend payloads provide:
```json
{
  "type": "email.opened",
  "created_at": "2026-09-09T16:00:00.000Z",
  "data": {
    "created_at": "2026-09-09T15:59:00.000Z",
    "email_id": "5ef3d940-0288-433b-a25e-3367ec968fbb",
    "from": "b2b@hatake.social",
    "to": ["vendor@example.com"],
    "subject": "Acme, join Hatake.Shop B2B",
    "click": {
      "link": "https://hatake.shop/login?invite=...",
      "timestamp": "2026-09-09T16:00:00.000Z"
    }
  }
}
```

Robust identifier extraction:
```ts
const eventType = (payload.type || '').replace(/^email\./, '').toLowerCase();
const data = payload.data || payload;

let recipientEmail: string | null = null;
if (Array.isArray(data.to) && data.to.length > 0) {
  recipientEmail = data.to[0];
} else if (typeof data.to === 'string') {
  recipientEmail = data.to;
} else if (typeof data.email === 'string') {
  recipientEmail = data.email;
} else if (typeof data.recipient === 'string') {
  recipientEmail = data.recipient;
} else if (typeof payload.email === 'string') {
  recipientEmail = payload.email;
}

const resendEmailId = data.email_id || payload.email_id || null;
```

#### 5.2.3 State Machine Transition Rules
To preserve data integrity:
1. **Recruited is Terminal**: Never downgrade a lead with `status === 'recruited'` back to `opened` or `clicked`.
2. **Clicked > Opened**: A `clicked` lead must not be downgraded to `opened` if an out-of-order `email.opened` event arrives later.
3. **Clicked Implies Opened**: If an `email.clicked` event arrives without prior open, set both `clickedAt` and `openedAt` (if `openedAt` was null).

Implementation logic:
```ts
// 1. Locate Lead
let leadRecord = null;
if (resendEmailId) {
  const byId = await db.select().from(leads).where(eq(leads.resendEmailId, resendEmailId)).limit(1);
  if (byId.length > 0) leadRecord = byId[0];
}
if (!leadRecord && recipientEmail) {
  const byEmail = await db.select().from(leads).where(ilike(leads.email, recipientEmail.trim())).limit(1);
  if (byEmail.length > 0) leadRecord = byEmail[0];
}

if (!leadRecord) {
  return res.status(200).json({ received: true, matched: false, message: "Lead not found" });
}

const now = new Date();
const currentStatus = leadRecord.status;
let updatedStatus = currentStatus;
const updates: Record<string, any> = {};

if (eventType === 'clicked') {
  if (currentStatus !== 'recruited') {
    updatedStatus = 'clicked';
    updates.status = 'clicked';
  }
  updates.clickedAt = now;
  if (!leadRecord.openedAt) updates.openedAt = now;
} else if (eventType === 'opened') {
  if (currentStatus !== 'recruited' && currentStatus !== 'clicked') {
    updatedStatus = 'opened';
    updates.status = 'opened';
  }
  if (!leadRecord.openedAt) updates.openedAt = now;
} else if (eventType === 'delivered') {
  if (currentStatus === 'sent') {
    // Optional: mark delivered or maintain sent
    updates.status = 'delivered';
    updatedStatus = 'delivered';
  }
} else if (eventType === 'bounced') {
  if (currentStatus !== 'recruited') {
    updates.status = 'failed';
    updatedStatus = 'failed';
  }
}

if (Object.keys(updates).length > 0) {
  await db.update(leads).set(updates).where(eq(leads.id, leadRecord.id));
}

// Real-time broadcast via Socket.IO
const io = (req as any).io;
if (io) {
  io.emit("lead_updated", {
    id: leadRecord.id,
    email: leadRecord.email,
    status: updatedStatus,
    openedAt: updates.openedAt || leadRecord.openedAt,
    clickedAt: updates.clickedAt || leadRecord.clickedAt,
  });
}

return res.status(200).json({
  received: true,
  matched: true,
  event: eventType,
  leadId: leadRecord.id,
  status: updatedStatus
});
```

---

## 6. Migration and Schema Alteration Blueprint

To support the above architecture, execute the following changes:

### 6.1 `src/db/schema.ts`
Update the `leads` table definition:
```ts
export const leads = pgTable('leads', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  companyName: text('company_name'),
  location: text('location'),
  segment: text('segment').default('TCG'),
  status: text('status', { enum: ['pending', 'sent', 'delivered', 'opened', 'clicked', 'recruited', 'failed'] }).default('pending'),
  website: text('website'),
  socialLinks: jsonb('social_links').default(sql`'[]'::jsonb`),
  inviteTokenHash: text('invite_token_hash'),
  openedAt: timestamp('opened_at'),
  clickedAt: timestamp('clicked_at'),
  resendEmailId: text('resend_email_id'),
  dripStep: integer('drip_step').default(1),
  lastEmailedAt: timestamp('last_emailed_at'),
  referredById: integer('referred_by_id'),
  redeemedAt: timestamp('redeemed_at'),
  sentAt: timestamp('sent_at'),
  createdAt: timestamp('created_at').defaultNow(),
});
```

### 6.2 Database Migration SQL
Execute the following statements against PostgreSQL:
```sql
ALTER TABLE "leads" ADD COLUMN IF NOT EXISTS "clicked_at" timestamp;
ALTER TABLE "leads" ADD COLUMN IF NOT EXISTS "resend_email_id" text;
CREATE INDEX IF NOT EXISTS "leads_status_idx" ON "leads" ("status");
CREATE INDEX IF NOT EXISTS "leads_resend_email_id_idx" ON "leads" ("resend_email_id");
CREATE INDEX IF NOT EXISTS "leads_invite_token_hash_idx" ON "leads" ("invite_token_hash");
```

---

## 7. Frontend Integration Touchpoints

1. **`src/pages/AdminDashboard.tsx`**:
   - Update `sentCount` computation in the UI if needed.
   - Add status badge colors for `opened` (e.g. amber/yellow) and `clicked` (e.g. purple/indigo).
   - In the filter dropdown (`leadFilter`), add options for `opened` and `clicked`.
   - Update button label to `"Send Next 50 Invites"`.
   - Listen to Socket.IO event `lead_updated` to dynamically update leads table in real time without manual browser refresh.
2. **`src/pages/DatabaseViewer.tsx`**:
   - Add backend endpoint `/api-v2/admin/raw-leads` in `server.ts` or redirect `DatabaseViewer.tsx` to `/api-v2/admin/leads` to resolve the 404 error currently logged.
