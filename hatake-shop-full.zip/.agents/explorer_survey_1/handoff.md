# Handoff Report — Backend & Database Exploration for Vendor Outreach Engine

**Agent**: `explorer_survey_1` (Backend & Database Explorer)  
**Date**: 2026-09-09  
**Handoff Type**: Hard (Task Complete)  
**Related Analysis**: `/home/ewilliamhe/hatake-shop/.agents/explorer_survey_1/analysis.md`

---

## 1. Observation

1. **Server Entry Point and Middleware**:
   - `server.ts:4` imports `express` (`"express": "^4.21.2"` in `package.json:30`).
   - `server.ts:116-120` initializes Express and Socket.IO:
     ```ts
     const app = express();
     const httpServer = createServer(app);
     const io = new Server(httpServer, { cors: { origin: "*" } });
     ```
   - `server.ts:220-223` attaches Socket.IO to request objects:
     ```ts
     app.use((req, res, next) => {
       (req as any).io = io;
       next();
     });
     ```
   - `server.ts:291` defines Stripe raw body webhook:
     ```ts
     app.post("/api-v2/stripe/webhook", express.raw({ type: 'application/json' }), async (req, res) => { ... });
     ```
   - `server.ts:324-325` mounts JSON and URL-encoded body parsers:
     ```ts
     app.use(express.json({ limit: '50mb' }));
     app.use(express.urlencoded({ limit: '50mb', extended: true }));
     ```
   - `server.ts:345-354` defines `requireAdmin` which checks `userProfile?.role !== 'admin'`.

2. **Database and ORM Setup**:
   - `package.json:29` uses `"drizzle-orm": "^0.45.2"` and `"pg": "^8.23.0"`.
   - `src/db/index.ts:1-38` connects via `pg.Pool` using `process.env.DATABASE_URL` (Neon Postgres).
   - `src/db/schema.ts:204-221` defines the `leads` table:
     ```ts
     export const leads = pgTable('leads', {
       id: serial('id').primaryKey(),
       email: text('email').notNull().unique(),
       companyName: text('company_name'),
       location: text('location'),
       segment: text('segment').default('TCG'),
       status: text('status', { enum: ['pending', 'sent', 'recruited', 'failed'] }).default('pending'),
       website: text('website'),
       socialLinks: jsonb('social_links').default(sql`'[]'::jsonb`),
       inviteTokenHash: text('invite_token_hash'),
       openedAt: timestamp('opened_at'),
       dripStep: integer('drip_step').default(1),
       lastEmailedAt: timestamp('last_emailed_at'),
       referredById: integer('referred_by_id'),
       redeemedAt: timestamp('redeemed_at'),
       sentAt: timestamp('sent_at'),
       createdAt: timestamp('created_at').defaultNow(),
     });
     ```
   - Current status enum is strictly `['pending', 'sent', 'recruited', 'failed']`.
   - Neither `clicked_at` nor `resend_email_id` are defined in `src/db/schema.ts`.
   - The PostgreSQL column type for `leads.status` is `text` with default `'pending'` (`drizzle/0001_majestic_carlie_cooper.sql:15`).

3. **Current Lead Sending Logic**:
   - `server.ts:10` instantiates Resend with a hardcoded fallback:
     ```ts
     const resend = new Resend(process.env.RESEND_API_KEY || "re_Cp41ejhy_3wYC8Bm2d8LxKzu3vsWoCwYP");
     ```
   - `.env` does not define `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, or `RESEND_REPLY_TO`.
   - `server.ts:584-623` defines `POST /api-v2/admin/leads/send`:
     - Queries `db.select().from(leads).where(eq(leads.status, 'pending')).limit(limit)`.
     - Generates UUID `rawToken`, hashes to `tokenHash`.
     - Calls `generateB2BEmailHtml(...)` (`src/lib/emailTemplate.ts:1-62`).
     - Dispatches via `resend.emails.send` with hardcoded `from: "Hatake <hello@hatake.shop>"` without `replyTo`.
     - Updates lead with `status: 'sent'`, `sentAt: new Date()`, and `inviteTokenHash: tokenHash`.

4. **Lead Recruitment & Metrics**:
   - `server.ts:1215-1229`: In `POST /api-v2/auth/sync`, incoming `inviteToken` is hashed and matches `leads.inviteTokenHash`, updating `status: 'recruited'` and `redeemedAt: new Date()`.
   - `server.ts:487` and `server.ts:649`: Compute `sentCount` via `where(eq(leads.status, 'sent'))`.

---

## 2. Logic Chain

1. **Funnel Tracking Expansion**:
   - From Observation 2, `leads.status` only allows `['pending', 'sent', 'recruited', 'failed']`.
   - Per requirement R2 and acceptance criteria, Resend webhooks must update leads to `'opened'` and `'clicked'`.
   - Therefore, `src/db/schema.ts` must update `leads.status` enum to include `'opened'` and `'clicked'` (and optionally `'delivered'`).
   - Additionally, adding `clickedAt: timestamp('clicked_at')` and `resendEmailId: text('resend_email_id')` to `src/db/schema.ts` and running `ALTER TABLE leads ADD COLUMN IF NOT EXISTS ...` enables precise click tracking and direct Resend email ID lookup.

2. **Webhook Endpoint Design**:
   - From Observation 1, global `express.json()` is mounted at `server.ts:324`.
   - Creating `POST /api-v2/webhooks/resend` after line 325 allows JSON payloads to be parsed automatically.
   - To satisfy Acceptance Criterion 2 (simulated `curl` payloads), the endpoint must accept payloads without requiring Svix signature headers when `RESEND_WEBHOOK_SECRET` is unset or headers are absent.
   - From Observation 1 (`server.ts:220`), `(req as any).io` is available on all request objects. The webhook handler can emit `io.emit("lead_updated", ...)` so the Admin Leads UI receives real-time status updates without polling.

3. **Batch Dispatching & Resend Integration**:
   - From Observation 3, the current sender uses `"Hatake <hello@hatake.shop>"` and an outdated API key.
   - To meet requirement R1, `.env` and `server.ts` must use:
     - `RESEND_API_KEY=re_HjG4pUYo_7BGA8K42zXd7w93JkYvRqUQv`
     - `RESEND_FROM_EMAIL=b2b@hatake.social`
     - `RESEND_REPLY_TO=ernst@hatake.eu`
   - In `POST /api-v2/admin/leads/send`, `resend.emails.send` must pass `from: "Hatake B2B <b2b@hatake.social>"`, `replyTo: "ernst@hatake.eu"`, and capture `res.data.id` into `leads.resendEmailId`.

4. **Preserving Terminal Funnel State**:
   - A vendor that has reached `recruited` must never be downgraded by an out-of-order `opened` or `clicked` webhook event.
   - A vendor with status `clicked` must not be downgraded to `opened`.
   - State transition rules must enforce forward progression only.

5. **Campaign Counter Fix**:
   - From Observation 4, `sentCount` is queried strictly with `where(eq(leads.status, 'sent'))`.
   - As leads progress to `opened`, `clicked`, or `recruited`, counting only `sent` leads will decrease the counter.
   - The query must be updated to `where(not(eq(leads.status, 'pending')))` so all contacted vendors contribute to the outreach total.

---

## 3. Caveats

1. **No Production Database Direct Alteration Performed**: As an explorer, no SQL alters or code modifications were made. The developer agent must run `ALTER TABLE leads ADD COLUMN IF NOT EXISTS clicked_at timestamp;` and `ALTER TABLE leads ADD COLUMN IF NOT EXISTS resend_email_id text;`.
2. **Resend Free Tier Rate Limits**: Sequential sending of 50 emails in a loop will make 50 HTTP requests to Resend. If Resend rate limits are encountered, adding a 50ms delay between calls or using `resend.batch.send()` may be implemented.
3. **DatabaseViewer `/api-v2/admin/raw-leads`**: Observed that `DatabaseViewer.tsx` calls an endpoint that does not exist in `server.ts`. This is outside the outreach engine scope but noted for awareness.

---

## 4. Conclusion

The existing Hatake Shop backend already contains Express, Drizzle ORM, Resend SDK, and Socket.IO. Upgrading it to support the Automated Vendor Outreach Engine requires:
1. Updating `src/db/schema.ts` to include `'opened'` and `'clicked'` in the `leads.status` enum, plus adding `clickedAt` and `resendEmailId`.
2. Configuring `.env` with the user-provided Resend credentials (`RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `RESEND_REPLY_TO`).
3. Updating `POST /api-v2/admin/leads/send` to use configured sender/reply-to headers and record `resendEmailId`.
4. Implementing public endpoint `POST /api-v2/webhooks/resend` in `server.ts` with forward-only funnel state transitions and Socket.IO real-time event broadcasting (`lead_updated`).
5. Adjusting `sentCount` queries in `server.ts:487` and `server.ts:649` to include `['sent', 'delivered', 'opened', 'clicked', 'recruited']`.

Detailed implementation blueprints, queries, and code snippets are available in `analysis.md`.

---

## 5. Verification Method

To independently verify the implementation:
1. **Type Check**:
   ```bash
   npm run lint
   ```
   Ensures `tsc --noEmit` validates the expanded Drizzle enum and types without compilation errors.
2. **Simulate Webhook via Curl**:
   ```bash
   curl -X POST http://localhost:3000/api-v2/webhooks/resend \
     -H "Content-Type: application/json" \
     -d '{"type": "email.opened", "data": { "to": ["mock_vendor@example.com"] }}'
   ```
   Inspect Postgres to verify `mock_vendor@example.com` has `status = 'opened'` and `opened_at` populated.
3. **Simulate Clicked Webhook**:
   ```bash
   curl -X POST http://localhost:3000/api-v2/webhooks/resend \
     -H "Content-Type: application/json" \
     -d '{"type": "email.clicked", "data": { "to": ["mock_vendor@example.com"] }}'
   ```
   Verify status transitions to `'clicked'`.
4. **Trigger Batch Dispatch via UI / API**:
   Trigger `POST /api-v2/admin/leads/send` with an authenticated admin token and inspect response `{ success: true, sent: 50 }` without 500 error.
